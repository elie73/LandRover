import "dotenv/config";
import pg from "pg";
import { scryptSync, randomBytes } from "crypto";

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

const d = (offset) => {
  const dt = new Date();
  dt.setDate(dt.getDate() + offset);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
};

const hash = (password) => {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
};

const main = async () => {
  const tables = [
    "uploads", "contacts", "reviews", "service_records", "appointments",
    "conversations", "vehicles", "customers", "technicians",
  ];
  for (const t of tables) await pool.query(`TRUNCATE TABLE "${t}" RESTART IDENTITY CASCADE`);

  /* technicians */
  const techs = [
    ["Karim Haddad", "Head of Workshop", "Air suspension · EAS calibration", "Master — JLR Certified", 24, "4.9", "https://images.pexels.com/photos/7564867/pexels-photo-7564867.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"],
    ["Elias Mroueh", "Master Technician", "Driveline · ZF transmissions", "Master — ZF Certified", 18, "4.9", "https://images.pexels.com/photos/6720496/pexels-photo-6720496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"],
    ["Dany Khoury", "Diagnostics Lead", "Electrical · CAN forensics", "Senior — IMI L4 HV", 14, "4.8", "https://images.pexels.com/photos/4489774/pexels-photo-4489774.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"],
    ["Sami Najjar", "Performance Engineer", "ECU calibration · dyno", "Senior — JLR Certified", 11, "4.8", "https://images.pexels.com/photos/28153670/pexels-photo-28153670.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"],
    ["Johnny Baydoun", "Service Advisor", "Owner care · service coordination", "Founder", 28, "5.0", "https://images.pexels.com/photos/4481952/pexels-photo-4481952.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"],
  ];
  for (const t of techs)
    await pool.query(
      `INSERT INTO technicians (name, role, specialization, level, years, rating, avatar) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      t
    );

  /* customers */
  await pool.query(
    `INSERT INTO customers (name, email, password_hash, phone, tier) VALUES ($1,$2,$3,$4,$5)`,
    ["Johnny Baydoun", "john@baydoun.com", hash("defender"), "+961 3 442 900", "Founder"]
  );
  await pool.query(
    `INSERT INTO customers (name, email, password_hash, phone, tier) VALUES ($1,$2,$3,$4,$5)`,
    ["Layla Haddad", "layla@baydoun.com", hash("discovery"), "+961 76 118 220", "Patron"]
  );

  /* vehicles */
  const veh = [
    [1, "SALLTAM28NA123456", "Defender 110 P400", 2022, "392841 B", "Santorini Black", 38420],
    [1, "SALWA2BK5LA765432", "Range Rover Sport HSE", 2020, "184552 B", "Carpathian Grey", 61230],
    [1, "SALLDHMF8HA444109", "Classic Defender 90", 1996, "90 CLASSIC", "Atlantis Blue", 148900],
    [2, "SALCR2BG0LH654321", "Discovery Sport R-Dynamic", 2021, "771203 B", "Firenze Red", 42110],
  ];
  for (const v of veh)
    await pool.query(
      `INSERT INTO vehicles (customer_id, vin, model, year, plate, color, mileage) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      v
    );

  /* appointments */
  const appts = [
    ["BLR-4821", 1, "Johnny Baydoun", 1, "Defender 110 P400", "Air Suspension", d(0), "09:00", "Karim Haddad", "in-service", 640, 150, "Front-left strut + compressor. Customer requests same-day.", "portal", null],
    ["BLR-2214", 1, "Johnny Baydoun", 2, "Range Rover Sport HSE", "Preventive Maintenance", d(1), "10:30", "Johnny Baydoun", "confirmed", 260, 90, "Annual service + 40-point inspection.", "ai", 1],
    ["BLR-7350", null, "Rami Kassar", null, "Range Rover Velar 2021", "Engine Diagnostics", d(2), "13:30", "Dany Khoury", "pending", 180, 90, "P0301 misfire reported cold. Contact: 03 555 210", "ai", 2],
    ["BLR-9102", 2, "Layla Haddad", 4, "Discovery Sport R-Dynamic", "Brake Systems", d(4), "15:00", "Johnny Baydoun", "confirmed", 310, 90, "Front pads + discs, fluid flush.", "ai", 3],
    ["BLR-5567", 1, "Johnny Baydoun", 1, "Defender 110 P400", "Software Updates", d(-6), "12:00", "Dany Khoury", "completed", 150, 60, "Pivi Pro update + module audit.", "portal", null],
    ["BLR-1188", null, "Omar T.", null, "Discovery 5 2019", "Transmission & Driveline", d(3), "09:00", "Elias Mroueh", "cancelled", 450, 120, "Customer postponed — moved off-platform.", "ai", 4],
  ];
  for (const a of appts)
    await pool.query(
      `INSERT INTO appointments (ref_code, customer_id, customer_name, vehicle_id, vehicle_label, service, date, time, technician, status, estimate, duration_min, notes, source, conversation_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`,
      a
    );

  /* conversations */
  const conv1 = [
    { role: "assistant", text: "Welcome! I'm Jane — Johnny's AI Assistant 👋 I'm your 24/7 Land Rover service assistant. How can I help you today?" },
    { role: "user", text: "Book a full service for my Range Rover Sport" },
    { role: "assistant", text: "Great choice — Preventive Maintenance (from $220). I can see your vehicles: which one is coming in?" },
    { role: "user", text: "Range Rover Sport HSE" },
    { role: "assistant", text: `Perfect — the Range Rover Sport HSE. Next openings: ${d(1)} (tomorrow). Which slot?` },
    { role: "user", text: "10:30" },
    { role: "assistant", text: "Booked ✅ Reference BLR-2214 — tomorrow at 10:30 with Johnny Baydoun. Thank you for choosing Baydoun Land Rover. Drive safely! 🙏" },
  ];
  await pool.query(
    `INSERT INTO conversations (customer_id, visitor_name, intent, state, messages) VALUES ($1,$2,$3,$4,$5)`,
    [1, "Johnny Baydoun", "booked", JSON.stringify({ mode: "idle" }), JSON.stringify(conv1)]
  );
  const conv2 = [
    { role: "user", text: "My Velar has a misfire when cold" },
    { role: "assistant", text: "Analysis complete. Probable: ignition coil or injector on cylinder 1 — urgency: book within 48h, est. $180–$600. Want me to book diagnostics?" },
    { role: "user", text: "Yes, book it" },
    { role: "assistant", text: "Booked ✅ BLR-7350 — engine diagnostics with Dany Khoury." },
  ];
  await pool.query(
    `INSERT INTO conversations (customer_id, visitor_name, intent, state, messages) VALUES ($1,$2,$3,$4,$5)`,
    [null, "Rami Kassar", "booked", JSON.stringify({ mode: "idle" }), JSON.stringify(conv2)]
  );
  const conv3 = [
    { role: "user", text: "Brake service for my Discovery Sport please" },
    { role: "assistant", text: "Booked ✅ BLR-9102 — front pads + discs with fluid flush." },
  ];
  await pool.query(
    `INSERT INTO conversations (customer_id, visitor_name, intent, state, messages) VALUES ($1,$2,$3,$4,$5)`,
    [2, "Layla Haddad", "booked", JSON.stringify({ mode: "idle" }), JSON.stringify(conv3)]
  );
  await pool.query(
    `INSERT INTO conversations (customer_id, visitor_name, intent, state, messages) VALUES ($1,$2,$3,$4,$5)`,
    [null, "Omar T.", "cancelled", JSON.stringify({ mode: "idle" }), JSON.stringify([{ role: "user", text: "Book gearbox service" }, { role: "assistant", text: "Booked BLR-1188." }, { role: "user", text: "Cancel BLR-1188" }, { role: "assistant", text: "Done — cancelled, no charge." }])]
  );

  /* service records (12 months of revenue) */
  const records = [
    [1, "INV-2291", "Air suspension compressor + front struts", "Air Suspension", d(-18), 36980, "Karim Haddad", 1480, "completed", "Wabco compressor, genuine struts, calibrated."],
    [2, "INV-2284", "ZF 8HP service + adaptation relearn", "Transmission", d(-35), 59100, "Elias Mroueh", 940, "completed", "Fluid, pan, mech seals."],
    [1, "INV-2272", "Annual service + brake fluid flush", "Preventive Maintenance", d(-62), 33150, "Johnny Baydoun", 310, "completed", "Genuine filters, Castrol 0W-20."],
    [2, "INV-2261", "Pivi Pro software campaign + module audit", "Software", d(-88), 57300, "Dany Khoury", 150, "completed", "TCU update resolved blackouts."],
    [1, "INV-2249", "Brake discs + pads (front & rear)", "Brake Systems", d(-120), 30400, "Johnny Baydoun", 620, "completed", "Genuine Brembo OE."],
    [3, "INV-2238", "Classic Defender 2.5TDI head rebuild", "Engine", d(-150), 143200, "Karim Haddad", 2850, "completed", "Full rebuild, new injection pump."],
    [4, "INV-2227", "Rear differential bush refresh + alignment", "Suspension", d(-178), 40800, "Elias Mroueh", 460, "completed", "Poly bushes, 3D alignment."],
    [1, "INV-2215", "Parasitic drain trace + BMS reset", "Electrical", d(-205), 27900, "Dany Khoury", 380, "completed", "Aftermarket dashcam was the drain."],
    [2, "INV-2204", "HV battery health report + cell balance", "Hybrid Systems", d(-240), 54100, "Dany Khoury", 340, "completed", "96% SoH — no action needed."],
    [1, "INV-2193", "Stage 1 ECU calibration + dyno", "Performance", d(-275), 25100, "Sami Najjar", 1350, "completed", "+47 bhp verified, three consistent pulls."],
    [3, "INV-2181", "Expedition build: lift, protection, snorkel", "Off-Road Upgrades", d(-310), 139800, "Karim Haddad", 4600, "completed", "2\" lift with geometry correction."],
    [2, "INV-2170", "AGM battery + BMS registration", "Battery Systems", d(-340), 52600, "Johnny Baydoun", 260, "completed", "Varta AGM registered."],
  ];
  for (const r of records)
    await pool.query(
      `INSERT INTO service_records (vehicle_id, invoice_no, title, category, date, mileage, technician, cost, status, notes) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      r
    );

  /* reviews */
  const revs = [
    ["Nabil G.", "Defender 110", 5, "The dealership quoted a full loom replacement. Dany found one corroded connector in 40 minutes and saved me $3,000. This is what expertise looks like.", "Google"],
    ["Sarah M.", "Range Rover Velar", 5, "Jane the AI assistant booked my air suspension repair at 2am. The car was fixed the same day with a courtesy Defender waiting outside. Unreal service.", "Website"],
    ["Karim A.", "Classic Defender 90", 5, "They rebuilt my 1996 90 like it left Solihull yesterday. Every bolt torqued, every panel aligned. Worth every penny.", "Google"],
    ["Rana K.", "Discovery Sport", 4, "Transparent pricing, photos of everything before and after, and the digital service book is genuinely useful at resale.", "WhatsApp"],
    ["Omar H.", "Range Rover Sport", 5, "The live repair timeline in the portal is addictive. I watched my car's brake job happen stage by stage.", "Google"],
    ["Dana F.", "Defender 130", 5, "Booked via chat, picked up by their truck, returned with a wash and a printed report. Porsche-level experience for a Land Rover.", "Website"],
  ];
  for (const r of revs)
    await pool.query(
      `INSERT INTO reviews (name, vehicle, rating, body, source) VALUES ($1,$2,$3,$4,$5)`,
      r
    );

  /* uploads */
  await pool.query(
    `INSERT INTO uploads (customer_id, kind, url, label) VALUES ($1,$2,$3,$4)`,
    [1, "photo", "https://images.pexels.com/photos/35474226/pexels-photo-35474226.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", "Defender grille — pre-winter check"]
  );
  await pool.query(
    `INSERT INTO uploads (customer_id, kind, url, label) VALUES ($1,$2,$3,$4)`,
    [1, "document", "/images/restore-after.jpg", "Classic 90 — handover photos"]
  );

  console.log("Seed complete.");
  await pool.end();
};

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
