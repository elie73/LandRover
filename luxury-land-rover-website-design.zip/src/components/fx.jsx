"use client";
import {
  useEffect,
  useRef,
  useState
} from "react";
const prefersReducedMotion = () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
function Reveal({
  children,
  delay = 0,
  className = "",
  style
}) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersReducedMotion()) {
      el.classList.add("is-in");
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            el.classList.add("is-in");
            io.disconnect();
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return <div ref={ref} className={`reveal ${className}`} style={{ transitionDelay: `${delay}ms`, ...style }}>
      {children}
    </div>;
}
const GLYPHS = "\u2593\u2592\u2591<>/\\|=+*#0123456789ABCDEF";
function Scramble({
  text,
  className = "",
  delay = 0,
  speed = 26
}) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersReducedMotion()) {
      el.textContent = text;
      return;
    }
    let frame = 0;
    let raf = 0;
    let started = false;
    const total = text.length;
    const tick = () => {
      frame++;
      const reveal = Math.floor(frame / 2.4);
      let out = "";
      for (let i = 0; i < total; i++) {
        if (i < reveal) out += text[i];
        else if (text[i] === " ") out += " ";
        else out += GLYPHS[Math.floor(Math.random() * GLYPHS.length)];
      }
      el.textContent = out;
      if (reveal < total) raf = requestAnimationFrame(tick);
      else el.textContent = text;
    };
    const io = new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting) && !started) {
        started = true;
        setTimeout(() => {
          raf = requestAnimationFrame(tick);
        }, delay);
        io.disconnect();
      }
    });
    io.observe(el);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [text, delay, speed]);
  return <span ref={ref} className={className} aria-label={text} />;
}
function Counter({
  to,
  suffix = "",
  prefix = "",
  duration = 1600,
  className = ""
}) {
  const ref = useRef(null);
  const [val, setVal] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersReducedMotion()) {
      setVal(to);
      return;
    }
    let raf = 0;
    const io = new IntersectionObserver((entries) => {
      if (!entries.some((e) => e.isIntersecting)) return;
      io.disconnect();
      const start = performance.now();
      const step = (now) => {
        const p = Math.min(1, (now - start) / duration);
        const eased = 1 - Math.pow(1 - p, 3);
        setVal(Math.round(to * eased));
        if (p < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    });
    io.observe(el);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [to, duration]);
  return <span ref={ref} className={className}>
      {prefix}
      {val.toLocaleString("en-US")}
      {suffix}
    </span>;
}
function Marquee({ children, speed = 36 }) {
  return <div className="overflow-hidden" style={{ "--marquee-speed": `${speed}s` }}>
      <div className="marquee-track">
        <div className="flex shrink-0 items-center">{children}</div>
        <div className="flex shrink-0 items-center" aria-hidden>
          {children}
        </div>
      </div>
    </div>;
}
function Cursor() {
  const dotRef = useRef(null);
  const ringRef = useRef(null);
  useEffect(() => {
    if (prefersReducedMotion()) return;
    if (!window.matchMedia("(pointer: fine)").matches) return;
    const dot = dotRef.current;
    const ring = ringRef.current;
    if (!dot || !ring) return;
    let x = -100, y = -100, rx = -100, ry = -100;
    let scale = 1;
    let raf = 0;
    const move = (e) => {
      x = e.clientX;
      y = e.clientY;
      const t = e.target;
      const interactive = !!t.closest("a, button, input, textarea, select, [data-mag], label, [role='button']");
      scale = interactive ? 2.1 : 1;
    };
    const loop = () => {
      rx += (x - rx) * 0.16;
      ry += (y - ry) * 0.16;
      dot.style.transform = `translate(${x - 3}px, ${y - 3}px)`;
      ring.style.transform = `translate(${rx - 16}px, ${ry - 16}px) scale(${scale})`;
      raf = requestAnimationFrame(loop);
    };
    window.addEventListener("mousemove", move, { passive: true });
    raf = requestAnimationFrame(loop);
    return () => {
      window.removeEventListener("mousemove", move);
      cancelAnimationFrame(raf);
    };
  }, []);
  return <>
      <div
    ref={dotRef}
    aria-hidden
    className="pointer-events-none fixed left-0 top-0 z-[120] hidden h-1.5 w-1.5 rounded-full bg-lime md:block"
  />
      <div
    ref={ringRef}
    aria-hidden
    className="pointer-events-none fixed left-0 top-0 z-[119] hidden h-8 w-8 rounded-full border border-lime/50 transition-[border-color] duration-300 md:block"
  />
    </>;
}
function SectionHead({
  kicker,
  title,
  right,
  className = ""
}) {
  return <div className={`mb-10 flex flex-wrap items-end justify-between gap-6 md:mb-14 ${className}`}>
      <div>
        <Reveal>
          <p className="mono-label mb-4 flex items-center gap-3">
            <span className="inline-block h-px w-10 bg-lime/70" />
            {kicker}
          </p>
        </Reveal>
        <h2 className="font-display text-4xl font-bold uppercase leading-[0.95] tracking-tight text-ink sm:text-5xl lg:text-6xl">
          <Reveal delay={80}>{title}</Reveal>
        </h2>
      </div>
      {right ? <Reveal delay={160}>{right}</Reveal> : null}
    </div>;
}
function CompareSlider({ before, after }) {
  const [pos, setPos] = useState(50);
  return <div className="relative aspect-[4/3] select-none overflow-hidden border border-line" data-mag>
      <img src={after} alt="After" className="absolute inset-0 h-full w-full object-cover" draggable={false} />
      <img
    src={before}
    alt="Before"
    className="absolute inset-0 h-full w-full object-cover"
    style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
    draggable={false}
  />
      <div className="pointer-events-none absolute inset-y-0" style={{ left: `${pos}%` }}>
        <div className="absolute inset-y-0 -ml-px w-0.5 bg-lime" />
        <div className="absolute top-1/2 -ml-5 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full border border-lime bg-pit/80 backdrop-blur">
          <svg width="18" height="12" viewBox="0 0 18 12" fill="none" stroke="currentColor" className="text-lime">
            <path d="M5 1 1 6l4 5M13 1l4 5-4 5" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
      <span className="absolute left-3 top-3 rounded-sm bg-pit/70 px-2 py-1 font-mono text-[10px] uppercase tracking-widest text-mute backdrop-blur">
        Before
      </span>
      <span className="absolute right-3 top-3 rounded-sm bg-lime px-2 py-1 font-mono text-[10px] uppercase tracking-widest text-pit">
        After
      </span>
      <input
    type="range"
    min={2}
    max={98}
    value={pos}
    onChange={(e) => setPos(Number(e.target.value))}
    aria-label="Drag to compare before and after"
    className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0"
  />
    </div>;
}
const PATHS = {
  wrench: <path d="M14.7 6.3a4.5 4.5 0 0 0-6 5.6L3 17.6V21h3.4l5.7-5.7a4.5 4.5 0 0 0 5.6-6L14.5 12l-2.5-2.5 2.7-3.2Z" />,
  gauge: <>
      <path d="M12 21a9 9 0 1 1 9-9" />
      <path d="M12 12l5-3" />
      <path d="M21 16.5A9 9 0 0 1 12 21" />
    </>,
  bolt: <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" />,
  shield: <>
      <path d="M12 2 4 5v6c0 5 3.4 8.8 8 11 4.6-2.2 8-6 8-11V5l-8-3Z" />
      <path d="m8.5 11.5 2.5 2.5 4.5-4.5" />
    </>,
  calendar: <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M8 3v4M16 3v4M3 10h18" />
    </>,
  pin: <>
      <path d="M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11Z" />
      <circle cx="12" cy="10" r="2.6" />
    </>,
  phone: <path d="M4 4h4l2 5-2.5 1.5a12 12 0 0 0 6 6L15 14l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 2 6a2 2 0 0 1 2-2Z" />,
  chat: <path d="M21 12a8 8 0 0 1-8 8H4l2.2-3.3A8 8 0 1 1 21 12Z" />,
  arrow: <path d="M4 12h16m-6-6 6 6-6 6" />,
  check: <path d="m4 12.5 5 5L20 6.5" />,
  star: <path d="m12 2 3 6.6 7 .8-5.2 4.8 1.4 7-6.2-3.6L5.8 21l1.4-7L2 9.4l7-.8L12 2Z" />,
  chip: <>
      <rect x="6" y="6" width="12" height="12" rx="1.5" />
      <path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4" />
    </>,
  lift: <path d="M3 21h18M6 21V10m12 11V10M6 10l6-6 6 6M9.5 14h5M9.5 17.5h5" />,
  key: <>
      <circle cx="8" cy="14" r="4.5" />
      <path d="m11.5 10.5 8-8M17 5l2.5 2.5M14.5 7.5 17 10" />
    </>,
  doc: <>
      <path d="M6 2h8l5 5v15H6V2Z" />
      <path d="M14 2v5h5M9.5 13h6M9.5 17h6" />
    </>,
  whatsapp: <>
      <path d="M12 2.5a9.5 9.5 0 0 0-8.13 14.4L2.5 21.5l4.73-1.32A9.5 9.5 0 1 0 12 2.5Z" />
      <path d="M8.8 7.9c-.3.01-.7.12-.97.45-.9 1.06-.68 2.77.45 4.31 1.12 1.55 2.93 3 4.97 3.5 1.25.3 2.33.04 2.86-.55.25-.28.37-.6.32-.9l-.06-.3c-.05-.2-.2-.3-.4-.38l-1.28-.56c-.18-.08-.38-.04-.53.1l-.5.48c-.15.15-.37.18-.57.1a8 8 0 0 1-3.4-3.1c-.12-.22-.08-.47.08-.65l.44-.5c.14-.16.18-.37.1-.56L9.72 8.3c-.12-.27-.45-.42-.75-.4h-.17Z" />
    </>
};
function Icon({ name, size = 20, className = "" }) {
  return <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.6"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden
  >
      {PATHS[name] ?? PATHS.wrench}
    </svg>;
}
function TypingDots() {
  return <span className="inline-flex items-center gap-1" aria-label="Jane is typing">
      {[0, 1, 2].map((i) => <span
    key={i}
    className="h-1.5 w-1.5 rounded-full bg-lime/80"
    style={{ animation: `typing 1s ${i * 0.15}s infinite` }}
  />)}
    </span>;
}
export {
  CompareSlider,
  Counter,
  Cursor,
  Icon,
  Marquee,
  Reveal,
  Scramble,
  SectionHead,
  TypingDots,
  prefersReducedMotion
};
