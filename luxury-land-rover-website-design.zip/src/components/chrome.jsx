"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { WORKSHOP } from "@/lib/services";
import { SERVICES } from "@/lib/services";
import { Icon } from "@/components/fx";
const NAV = [
  { href: "/", label: "Home" },
  { href: "/services", label: "Services" },
  { href: "/about", label: "The Atelier" },
  { href: "/gallery", label: "Gallery" },
  { href: "/reviews", label: "Reviews" },
  { href: "/faq", label: "FAQ" },
  { href: "/contact", label: "Contact" }
];
function Logo({ compact = false }) {
  return <Link href="/" className="group flex items-center gap-3" aria-label="Baydoun Land Rover — home">
      <span className="relative grid h-10 w-10 place-items-center border border-line2 bg-panel transition-colors duration-300 group-hover:border-lime/60">
        <span className="font-display text-xl font-bold text-lime">B</span>
        <span className="absolute -right-px -top-px h-2 w-2 border-r border-t border-lime" />
        <span className="absolute -bottom-px -left-px h-2 w-2 border-b border-l border-lime" />
      </span>
      {!compact && <span className="leading-none">
          <span className="block font-display text-lg font-bold uppercase tracking-[0.08em] text-ink">
            Baydoun
          </span>
          <span className="mono-label block !text-[9px] text-mute">Land Rover Atelier</span>
        </span>}
    </Link>;
}
function StatusTicker() {
  const hour = (/* @__PURE__ */ new Date()).getHours();
  const day = (/* @__PURE__ */ new Date()).getDay();
  const open = day !== 0 && hour >= 8 && hour < 18;
  return <div className="relative z-[60] flex items-center justify-between gap-4 border-b border-line bg-pit/90 px-4 py-1.5 backdrop-blur md:px-8">
      <p className="flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.18em] text-mute">
        <span
    className={`inline-block h-1.5 w-1.5 rounded-full ${open ? "bg-lime pulse-dot" : "bg-gold"}`}
  />
        <span className="hidden sm:inline">{open ? "Workshop open" : "Workshop closed"} ·</span>
        <span>AI assistant online 24/7</span>
      </p>
      <p className="hidden font-mono text-[10px] uppercase tracking-[0.18em] text-dim md:block">
        {WORKSHOP.hours}
      </p>
    </div>;
}
function Nav() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [openMenu, setOpenMenu] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => setOpenMenu(false), [pathname]);
  return <header className="sticky top-0 z-[80]">
      <StatusTicker />
      <nav
    className={`border-b transition-all duration-500 ${scrolled || openMenu ? "border-line bg-bg/90 backdrop-blur-xl" : "border-transparent bg-transparent"}`}
  >
        <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-6 px-4 py-3.5 md:px-8">
          <Logo />
          <div className="hidden items-center gap-1 lg:flex">
            {NAV.map((item) => {
    const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
    return <Link
      key={item.href}
      href={item.href}
      className={`relative px-3 py-2 font-display text-[13px] font-semibold uppercase tracking-[0.12em] transition-colors duration-300 ${active ? "text-lime" : "text-mute hover:text-ink"}`}
    >
                  {item.label}
                  {item.href === "/assistant" && <span className="absolute right-0.5 top-1.5 h-1.5 w-1.5 rounded-full bg-lime pulse-dot" />}
                  {active && <span className="absolute inset-x-3 -bottom-px h-px bg-lime" />}
                </Link>;
  })}
          </div>
          <div className="hidden lg:block" aria-hidden />
          <button
    onClick={() => setOpenMenu((v) => !v)}
    aria-label={openMenu ? "Close menu" : "Open menu"}
    aria-expanded={openMenu}
    className="grid h-11 w-11 place-items-center border border-line2 text-ink lg:hidden"
  >
            <span className="relative block h-3 w-5">
              <span
    className={`absolute left-0 top-0 h-px w-full bg-current transition-all duration-300 ${openMenu ? "top-1.5 rotate-45" : ""}`}
  />
              <span
    className={`absolute left-0 top-1.5 h-px w-full bg-current transition-opacity duration-300 ${openMenu ? "opacity-0" : ""}`}
  />
              <span
    className={`absolute left-0 top-3 h-px w-full bg-current transition-all duration-300 ${openMenu ? "top-1.5 -rotate-45" : ""}`}
  />
            </span>
          </button>
        </div>
        {
    /* mobile menu */
  }
        <div
    className={`grid overflow-hidden border-line transition-all duration-500 lg:hidden ${openMenu ? "grid-rows-[1fr] border-t" : "grid-rows-[0fr]"}`}
  >
          <div className="min-h-0 overflow-hidden bg-bg/95 backdrop-blur-xl">
            <div className="flex flex-col gap-1 px-4 py-5">
              {NAV.map((item, i) => <Link
    key={item.href}
    href={item.href}
    className={`border-b border-line/60 py-3.5 font-display text-xl font-semibold uppercase tracking-wide transition-colors ${(item.href === "/" ? pathname === "/" : pathname.startsWith(item.href)) ? "text-lime" : "text-ink"}`}
    style={{ transitionDelay: `${i * 30}ms` }}
  >
                  {item.label}
                </Link>)}
              <div className="mt-4 flex gap-3">
                <Link href="/portal" className="btn-ghost flex-1 justify-center text-sm">
                  Portal
                </Link>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </header>;
}
function Footer() {
  return <footer className="relative mt-28 overflow-hidden border-t border-line bg-pit">
      <div className="pointer-events-none absolute inset-0 carbon opacity-40" />
      <div className="relative mx-auto max-w-[1400px] px-4 pb-10 pt-16 md:px-8">
        <p
    aria-hidden
    className="text-outline pointer-events-none select-none whitespace-nowrap font-display text-[19vw] font-bold uppercase leading-[0.8] opacity-60 lg:text-[240px]"
  >
          Baydoun
        </p>
        <div className="mt-10 grid gap-12 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <Logo />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-mute">
              The world's most advanced Land Rover specialist — where precision engineering meets
              British luxury. Master technicians, genuine parts, and an AI assistant that never
              sleeps.
            </p>
            <div className="mt-6 flex gap-3">
              {["IG", "YT", "X"].map((s) => <a
    key={s}
    href="#"
    onClick={(e) => e.preventDefault()}
    aria-label={`Social link ${s}`}
    className="grid h-10 w-10 place-items-center border border-line2 font-mono text-[10px] text-mute transition-all duration-300 hover:border-lime/60 hover:text-lime"
  >
                  {s}
                </a>)}
              <a
    href={WORKSHOP.whatsappLink}
    target="_blank"
    rel="noreferrer"
    aria-label={`WhatsApp ${WORKSHOP.whatsapp}`}
    title={`WhatsApp ${WORKSHOP.whatsapp}`}
    className="grid h-10 w-10 place-items-center border border-line2 text-mute transition-all duration-300 hover:border-[#25d366]/70 hover:bg-[#25d366]/10 hover:text-[#25d366]"
  >
                <Icon name="whatsapp" size={17} />
              </a>
            </div>
          </div>
          <div>
            <p className="mono-label mb-5">Explore</p>
            <ul className="space-y-3 text-sm text-mute">
              {[
    ["Services", "/services"],
    ["AI Assistant", "/assistant"],
    ["The Atelier", "/about"],
    ["Master Technicians", "/about"],
    ["Gallery", "/gallery"],
    ["Reviews", "/reviews"],
    ["FAQ & Knowledge Center", "/faq"],
    ["Careers", "/contact"],
    ["Fleet & Corporate", "/contact"]
  ].map(([label, href]) => <li key={label}>
                  <Link href={href} className="transition-colors hover:text-lime">
                    {label}
                  </Link>
                </li>)}
            </ul>
          </div>
          <div>
            <p className="mono-label mb-5">Services</p>
            <ul className="space-y-3 text-sm text-mute">
              {SERVICES.slice(0, 8).map((s) => <li key={s.slug}>
                  <Link href={`/services/${s.slug}`} className="transition-colors hover:text-lime">
                    {s.name}
                  </Link>
                </li>)}
            </ul>
          </div>
          <div>
            <p className="mono-label mb-5">Visit the atelier</p>
            <address className="space-y-3 text-sm not-italic leading-relaxed text-mute">
              <p className="flex gap-2.5">
                <Icon name="pin" size={16} className="mt-0.5 shrink-0 text-lime" />
                {WORKSHOP.address}
              </p>
              <p className="flex gap-2.5">
                <Icon name="phone" size={16} className="mt-0.5 shrink-0 text-lime" />
                {WORKSHOP.phone} · WA {WORKSHOP.whatsapp}
              </p>
              <p className="flex gap-2.5">
                <Icon name="calendar" size={16} className="mt-0.5 shrink-0 text-lime" />
                {WORKSHOP.hours}
              </p>
            </address>
            <div className="mt-6 grid grid-cols-1 gap-3">
              <Link href="/portal" className="btn-ghost justify-center !px-3 text-[12px]">
                <Icon name="key" size={15} />
                Owner Login
              </Link>
            </div>
          </div>
        </div>
        <div className="mt-14 flex flex-col items-start justify-between gap-4 border-t border-line pt-6 md:flex-row md:items-center">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-dim">
            © {(/* @__PURE__ */ new Date()).getFullYear()} Baydoun Land Rover SARL — Independent specialist. Not affiliated with Jaguar Land Rover Ltd.
          </p>
          <div className="flex gap-6 font-mono text-[10px] uppercase tracking-[0.18em] text-dim">
            <Link href="/faq" className="hover:text-mute">Privacy</Link>
            <Link href="/faq" className="hover:text-mute">Terms</Link>
            <Link href="/contact" className="hover:text-mute">Warranty</Link>
          </div>
        </div>
      </div>
    </footer>;
}
function AssistantFab() {
  return <Link
    href="/assistant?intent=book"
    aria-label="Open Baydoun AI Assistant"
    title="Baydoun AI Assistant"
    className="group fixed bottom-[86px] right-6 z-[85] grid h-13 w-13 place-items-center border border-lime/70 bg-lime text-pit shadow-[0_14px_40px_-10px_rgba(201,241,88,0.5)] transition-all duration-300 hover:-translate-y-1 hover:bg-[#d8fa74]"
  >
      <span className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full bg-pit pulse-dot" />
      <Icon name="chat" size={25} className="transition-transform duration-500 group-hover:scale-110" />
    </Link>;
}
function WhatsAppFab() {
  return <a
    href={WORKSHOP.whatsappLink}
    target="_blank"
    rel="noreferrer"
    aria-label={`Chat on WhatsApp \u2014 ${WORKSHOP.whatsapp}`}
    title={`WhatsApp ${WORKSHOP.whatsapp}`}
    className="group fixed bottom-6 right-6 z-[85] flex items-center gap-0 overflow-hidden border border-[#25d366]/50 bg-[#0d1f16] shadow-[0_14px_40px_-10px_rgba(37,211,102,0.45)] transition-all duration-500 hover:border-[#25d366] hover:pr-4"
  >
      <span className="relative grid h-13 w-13 shrink-0 place-items-center p-3.5">
        <span className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full bg-[#25d366] pulse-dot" />
        <Icon name="whatsapp" size={26} className="text-[#25d366] transition-transform duration-500 group-hover:scale-110" />
      </span>
      <span className="max-w-0 whitespace-nowrap font-mono text-[11px] uppercase tracking-[0.16em] text-[#25d366] opacity-0 transition-all duration-500 group-hover:max-w-[180px] group-hover:pl-1 group-hover:opacity-100">
        {WORKSHOP.whatsapp}
      </span>
    </a>;
}
export {
  AssistantFab,
  Footer,
  Logo,
  Nav,
  StatusTicker,
  WhatsAppFab
};
