import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  date,
  jsonb
} from "drizzle-orm/pg-core";
const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  phone: text("phone"),
  tier: text("tier").default("Owner"),
  createdAt: timestamp("created_at").defaultNow()
});
const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  vin: text("vin").notNull(),
  model: text("model").notNull(),
  year: integer("year").notNull(),
  plate: text("plate"),
  color: text("color"),
  mileage: integer("mileage")
});
const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  refCode: text("ref_code").notNull(),
  customerId: integer("customer_id"),
  customerName: text("customer_name"),
  vehicleId: integer("vehicle_id"),
  vehicleLabel: text("vehicle_label"),
  service: text("service").notNull(),
  date: date("date", { mode: "string" }).notNull(),
  time: text("time").notNull(),
  technician: text("technician"),
  status: text("status").notNull().default("pending"),
  estimate: integer("estimate"),
  durationMin: integer("duration_min"),
  notes: text("notes"),
  source: text("source").notNull().default("ai"),
  conversationId: integer("conversation_id"),
  createdAt: timestamp("created_at").defaultNow()
});
const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id"),
  visitorName: text("visitor_name"),
  intent: text("intent"),
  state: jsonb("state").$type().default({}),
  messages: jsonb("messages").$type().default([]),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
const serviceRecords = pgTable("service_records", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id").notNull(),
  invoiceNo: text("invoice_no").notNull(),
  title: text("title").notNull(),
  category: text("category"),
  date: date("date", { mode: "string" }).notNull(),
  mileage: integer("mileage"),
  technician: text("technician"),
  cost: integer("cost").notNull(),
  status: text("status").notNull().default("completed"),
  notes: text("notes")
});
const technicians = pgTable("technicians", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  specialization: text("specialization"),
  level: text("level"),
  years: integer("years"),
  rating: text("rating"),
  avatar: text("avatar")
});
const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  vehicle: text("vehicle"),
  rating: integer("rating").notNull(),
  body: text("body").notNull(),
  source: text("source").default("Website"),
  createdAt: timestamp("created_at").defaultNow()
});
const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  subject: text("subject"),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});
const uploads = pgTable("uploads", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id"),
  kind: text("kind").notNull().default("photo"),
  url: text("url").notNull(),
  label: text("label"),
  createdAt: timestamp("created_at").defaultNow()
});
export {
  appointments,
  contacts,
  conversations,
  customers,
  reviews,
  serviceRecords,
  technicians,
  uploads,
  vehicles
};
