"use client";
import { Fragment, useCallback, useEffect, useRef, useState } from "react";
import { Icon, Reveal } from "@/components/fx";
import { fmtMoney, labelDate, longDate, STATUS_STYLES } from "@/lib/utils";
const TABS = ["Overview", "Service history", "Vehicles", "Documents"];
function Badge({ status }) {
  return <span className={`inline-block border px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.14em] ${STATUS_STYLES[status] || STATUS_STYLES.pending}`}>
      {status}
    </span>;
}
function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) return setErr(data.error || "Login failed.");
    onLogin({ id: 0, name: data.name, email, tier: data.tier });
  };
  return <section className="relative flex min-h-[calc(100vh-97px)] items-center overflow-hidden">
      <div className="carbon absolute inset-0 opacity-50" aria-hidden />
      <div className="glow-racing pointer-events-none absolute -right-40 top-0 h-[520px] w-[720px]" aria-hidden />
      <div className="relative mx-auto grid w-full max-w-[1100px] gap-12 px-4 py-16 md:px-8 lg:grid-cols-2">
        <Reveal>
          <p className="mono-label mb-6 flex items-center gap-3">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime pulse-dot" /> Owner portal — secure access
          </p>
          <h1 className="font-display text-6xl font-bold uppercase leading-[0.88] text-ink md:text-7xl">
            Your Land Rover,
            <br />
            <span className="text-lime">fully documented.</span>
          </h1>
          <p className="mt-6 max-w-md text-base leading-relaxed text-mute">
            Live repair status, every invoice, AI conversation history, warranty documents and
            maintenance reminders — one passport for every vehicle you own.
          </p>
          <ul className="mt-8 space-y-3">
            {["Live repair timeline & technician notes", "Digital invoices & warranty vault", "AI booking transcripts with edit & delete", "Photo / video upload straight to your file"].map((t) => <li key={t} className="flex gap-3 text-sm text-mute">
                <Icon name="check" size={16} className="mt-0.5 shrink-0 text-lime" /> {t}
              </li>)}
          </ul>
        </Reveal>
        <Reveal delay={150}>
          <form onSubmit={submit} className="panel relative overflow-hidden p-8 md:p-10">
            <div className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-racing via-lime to-racing" />
            <p className="font-display text-2xl font-bold uppercase tracking-wide text-ink">Owner sign in</p>
            <p className="mt-1.5 text-sm text-mute">Credentials are encrypted end-to-end.</p>
            <label className="mt-7 block">
              <span className="mono-label">Email</span>
              <input
    type="email"
    required
    value={email}
    onChange={(e) => setEmail(e.target.value)}
    placeholder="you@example.com"
    autoComplete="email"
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
  />
            </label>
            <label className="mt-5 block">
              <span className="mono-label">Password</span>
              <input
    type="password"
    required
    value={password}
    onChange={(e) => setPassword(e.target.value)}
    placeholder="••••••••"
    autoComplete="current-password"
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
  />
            </label>
            {err && <p className="mt-4 border border-alert/40 bg-alert/10 px-3 py-2.5 text-sm text-alert">{err}</p>}
            <button type="submit" disabled={busy} className="btn-primary mt-7 w-full justify-center disabled:opacity-50">
              {busy ? "Verifying\u2026" : "Enter the portal"}
            </button>
            <div className="mt-6 border border-gold/30 bg-gold/5 p-4">
              <p className="mono-label mb-2 text-gold">Demo access</p>
              <p className="font-mono text-xs leading-relaxed text-mute">
                john@baydoun.com · <span className="text-ink">defender</span>
                <br />
                layla@baydoun.com · <span className="text-ink">discovery</span>
              </p>
            </div>
          </form>
        </Reveal>
      </div>
    </section>;
}
function EditModal({ appt, onClose, onSaved }) {
  const [date, setDate] = useState(appt.date);
  const [time, setTime] = useState(appt.time);
  const [notes, setNotes] = useState(appt.notes || "");
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    setErr(null);
    const res = await fetch("/api/portal/bookings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: appt.id, date, time, notes })
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) return setErr(data.error || "Could not save.");
    onSaved();
  };
  return <div className="fixed inset-0 z-[130] grid place-items-center bg-pit/80 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Edit booking">
      <div className="panel w-full max-w-md p-7">
        <div className="mb-5 flex items-center justify-between">
          <p className="font-display text-xl font-bold uppercase text-ink">Edit <span className="text-lime">{appt.refCode}</span></p>
          <button onClick={onClose} aria-label="Close" className="grid h-9 w-9 place-items-center border border-line2 text-mute hover:text-ink">✕</button>
        </div>
        <p className="mb-5 text-sm text-mute">{appt.service} · {appt.vehicleLabel || "Vehicle on file"}</p>
        <label className="block">
          <span className="mono-label">Date</span>
          <input
    type="date"
    value={date}
    min={(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}
    onChange={(e) => setDate(e.target.value)}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink focus:border-lime/60 focus:outline-none [color-scheme:dark]"
  />
        </label>
        <label className="mt-4 block">
          <span className="mono-label">Arrival time</span>
          <select
    value={time}
    onChange={(e) => setTime(e.target.value)}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink focus:border-lime/60 focus:outline-none"
  >
            {["09:00", "10:30", "12:00", "13:30", "15:00", "16:30"].map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </label>
        <label className="mt-4 block">
          <span className="mono-label">Notes for the workshop</span>
          <textarea
    value={notes}
    onChange={(e) => setNotes(e.target.value)}
    rows={3}
    className="mt-2 w-full resize-none border border-line2 bg-pit px-4 py-3 text-ink focus:border-lime/60 focus:outline-none"
  />
        </label>
        {err && <p className="mt-4 border border-alert/40 bg-alert/10 px-3 py-2.5 text-sm text-alert">{err}</p>}
        <div className="mt-6 flex gap-3">
          <button onClick={onClose} className="btn-ghost flex-1 justify-center !py-3 text-sm">Cancel</button>
          <button onClick={save} disabled={busy} className="btn-primary flex-1 justify-center !py-3 text-sm disabled:opacity-50">
            {busy ? "Saving\u2026" : "Save changes"}
          </button>
        </div>
      </div>
    </div>;
}
function PortalShell({ user, onLogout }) {
  const [tab, setTab] = useState("Overview");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editAppt, setEditAppt] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [openConv, setOpenConv] = useState(null);
  const [toast, setToast] = useState(null);
  const fileRef = useRef(null);
  const [kind, setKind] = useState("photo");
  const [uploading, setUploading] = useState(false);
  const [vehicleBusy, setVehicleBusy] = useState(false);
  const [vehicleForm, setVehicleForm] = useState({
    model: "",
    year: String((/* @__PURE__ */ new Date()).getFullYear()),
    vin: "",
    plate: "",
    color: "",
    mileage: ""
  });
  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/portal");
    if (res.ok) setData(await res.json());
    setLoading(false);
  }, []);
  useEffect(() => {
    load();
  }, [load]);
  const flash = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2600);
  };
  const notifyVehicleTelemetry = () => {
    const stamp = String(Date.now());
    window.localStorage.setItem("baydoun-vehicles-updated-at", stamp);
    window.dispatchEvent(new CustomEvent("baydoun-vehicles-updated"));
    if ("BroadcastChannel" in window) {
      const channel = new BroadcastChannel("baydoun-workshop-telemetry");
      channel.postMessage("vehicles-updated");
      channel.close();
    }
  };
  const doDelete = async () => {
    if (!confirmDelete) return;
    const res = await fetch(`/api/portal/bookings?id=${confirmDelete.id}`, { method: "DELETE" });
    setConfirmDelete(null);
    if (res.ok) {
      flash(`Booking ${confirmDelete.refCode} deleted.`);
      load();
    } else flash("Could not delete the booking.");
  };
  const onFile = async (f) => {
    if (!f) return;
    setUploading(true);
    const fd = new FormData();
    fd.append("file", f);
    fd.append("kind", kind);
    fd.append("label", f.name.replace(/\.[^.]+$/, "").slice(0, 60));
    const res = await fetch("/api/portal/upload", { method: "POST", body: fd });
    setUploading(false);
    if (fileRef.current) fileRef.current.value = "";
    if (res.ok) {
      flash("Upload saved to your vehicle file.");
      load();
    } else {
      const d = await res.json().catch(() => ({}));
      flash(d.error || "Upload failed.");
    }
  };
  const addVehicle = async (e) => {
    e.preventDefault();
    setVehicleBusy(true);
    const res = await fetch("/api/portal/vehicles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(vehicleForm)
    });
    const d = await res.json().catch(() => ({}));
    setVehicleBusy(false);
    if (!res.ok) return flash(d.error || "Could not add vehicle.");
    setVehicleForm({
      model: "",
      year: String((/* @__PURE__ */ new Date()).getFullYear()),
      vin: "",
      plate: "",
      color: "",
      mileage: ""
    });
    flash("Vehicle added to your garage.");
    notifyVehicleTelemetry();
    load();
  };
  const deleteVehicle = async (vehicle) => {
    if (!confirm(`Delete ${vehicle.model} from your garage?`)) return;
    const res = await fetch(`/api/portal/vehicles?id=${vehicle.id}`, { method: "DELETE" });
    const d = await res.json().catch(() => ({}));
    if (!res.ok) return flash(d.error || "Could not delete vehicle.");
    flash("Vehicle deleted from your garage.");
    notifyVehicleTelemetry();
    load();
  };
  if (loading || !data)
    return <section className="grid min-h-[60vh] place-items-center">
        <div className="text-center">
          <div className="mx-auto mb-5 h-12 w-12 animate-[spinSlow_1.2s_linear_infinite] border border-line2 border-t-lime" />
          <p className="mono-label">Loading your garage…</p>
        </div>
      </section>;
  const { vehicles, records, appointments, uploads } = data;
  const upcoming = appointments.filter((a) => a.status !== "cancelled" && a.status !== "completed");
  const spend = records.reduce((s, r) => s + r.cost, 0);
  const bayStatusFor = (vehicle) => {
    const appt = appointments.find((a) => {
      if (a.status === "cancelled" || a.status === "completed") return false;
      const label = (a.vehicleLabel || "").toLowerCase();
      return label.includes(vehicle.model.toLowerCase()) || vehicle.model.toLowerCase().includes(label);
    });
    if (!appt) return { label: "Clear", tone: "text-dim border-line2 bg-white/5", detail: "No active bay job" };
    if (appt.status === "in-service" || appt.status === "awaiting-parts")
      return { label: "In bay", tone: "text-lime border-lime/45 bg-lime/10", detail: `${appt.service} \xB7 ${appt.time}` };
    return { label: "Queued", tone: "text-gold border-gold/45 bg-gold/10", detail: `${appt.service} \xB7 ${appt.time}` };
  };
  return <section className="relative min-h-[calc(100vh-97px)]">
      <div className="carbon absolute inset-0 opacity-30" aria-hidden />
      {toast && <div className="anim-rise fixed left-1/2 top-24 z-[140] -translate-x-1/2 border border-lime/50 bg-pit px-5 py-3 font-mono text-xs uppercase tracking-widest text-lime shadow-[0_10px_40px_-10px_rgba(201,241,88,0.4)]">
          {toast}
        </div>}
      <div className="relative mx-auto max-w-[1400px] px-4 py-12 md:px-8">
        {
    /* header */
  }
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="mono-label mb-3">Owner portal · digital vehicle passport</p>
            <h1 className="font-display text-5xl font-bold uppercase leading-none text-ink md:text-6xl">
              Welcome back, <span className="text-lime">{user.name.split(" ")[0]}</span>
            </h1>
            <p className="mt-3 font-mono text-[11px] uppercase tracking-widest text-mute">
              {user.email} · tier: <span className="text-gold">{user.tier || "Owner"}</span>
            </p>
          </div>
          <button onClick={onLogout} className="btn-ghost !py-3 text-sm">
            <Icon name="key" size={15} /> Sign out
          </button>
        </div>

        {
    /* tabs */
  }
        <div className="mt-10 flex flex-wrap gap-px border border-line bg-line">
          {TABS.map((t) => <Fragment key={t}>
              <button
    onClick={() => setTab(t)}
    className={`px-5 py-3.5 font-display text-[13px] font-semibold uppercase tracking-[0.1em] transition-colors duration-300 ${tab === t ? "bg-lime text-pit" : "bg-panel text-mute hover:bg-panel2 hover:text-ink"}`}
  >
                {t}
              </button>
              {t === "Vehicles" && <a
    href="/admin"
    aria-label="Open Workshop OS admin dashboard"
    className="inline-flex items-center gap-2 bg-panel px-5 py-3.5 font-display text-[13px] font-semibold uppercase tracking-[0.1em] text-mute transition-colors duration-300 hover:bg-panel2 hover:text-lime"
  >
                  <Icon name="chip" size={15} />
                  Workshop OS
                </a>}
            </Fragment>)}
        </div>

        {
    /* ---------------- overview ---------------- */
  }
        {tab === "Overview" && <div className="mt-8 grid gap-5 lg:grid-cols-4">
            {[
    { k: "Vehicles on file", v: String(vehicles.length), icon: "lift" },
    { k: "Upcoming bookings", v: String(upcoming.length), icon: "calendar" },
    { k: "Lifetime service spend", v: fmtMoney(spend), icon: "doc" },
    { k: "Open recalls", v: "0", icon: "shield" }
  ].map((s, i) => <Reveal key={s.k} delay={i * 80}>
                <div className="border border-line bg-panel/70 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-lime/40">
                  <Icon name={s.icon} size={22} className="text-lime" />
                  <p className="mt-4 font-display text-4xl font-bold text-ink">{s.v}</p>
                  <p className="mono-label mt-2 !text-mute">{s.k}</p>
                </div>
              </Reveal>)}
            <Reveal className="lg:col-span-2" delay={200}>
              <div className="h-full border border-line bg-panel/70 p-6">
                <p className="mono-label mb-5">Next in the workshop</p>
                {upcoming.length === 0 && <p className="text-sm text-mute">Nothing scheduled — ask Jane to reserve a bay whenever you are ready.</p>}
                <div className="space-y-4">
                  {upcoming.slice(0, 2).map((a) => <div key={a.id} className="flex flex-wrap items-center justify-between gap-3 border border-line bg-pit/60 p-4">
                      <div>
                        <p className="font-mono text-xs tracking-widest text-lime">{a.refCode}</p>
                        <p className="mt-1 font-display text-lg font-semibold uppercase text-ink">{a.service}</p>
                        <p className="mt-0.5 text-sm text-mute">{longDate(a.date)} · {a.time} · {a.technician}</p>
                      </div>
                      <Badge status={a.status} />
                    </div>)}
                </div>
              </div>
            </Reveal>
            <Reveal className="lg:col-span-2" delay={280}>
              <div className="h-full border border-line bg-panel/70 p-6">
                <p className="mono-label mb-5">Maintenance reminders</p>
                <ul className="space-y-3.5">
                  {vehicles.slice(0, 3).map((v) => <li key={v.id} className="flex items-center justify-between gap-4 border-b border-line pb-3 text-sm">
                      <span className="text-ink">{v.model} <span className="text-dim">· {v.mileage?.toLocaleString()} km</span></span>
                      <span className="shrink-0 font-mono text-[10px] uppercase tracking-widest text-gold">
                        {v.year < 2e3 ? "Classic care plan" : "Service due in " + (90 + v.id * 17) + " days"}
                      </span>
                    </li>)}
                  {vehicles.length === 0 && <p className="text-sm text-mute">No vehicles registered yet.</p>}
                </ul>
              </div>
            </Reveal>
          </div>}

        {
    /* ---------------- appointments ---------------- */
  }
        {tab === "Appointments" && <div className="mt-8 space-y-5">
            {appointments.length === 0 && <div className="border border-line bg-panel/70 p-10 text-center">
                <p className="font-display text-2xl font-bold uppercase text-ink">No bookings yet</p>
                <p className="mt-2 text-sm text-mute">Everything you book with Jane appears here — with the full conversation.</p>
                <a href="/assistant?intent=book" className="btn-primary mx-auto mt-6">Book with the AI</a>
              </div>}
            {appointments.map((a, i) => <Reveal key={a.id} delay={Math.min(i * 70, 280)}>
                <div className="border border-line bg-panel/70 transition-colors duration-300 hover:border-line2">
                  <div className="flex flex-wrap items-center justify-between gap-4 p-6">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-3">
                        <span className="font-mono text-xs tracking-widest text-lime">{a.refCode}</span>
                        <Badge status={a.status} />
                        <span className="font-mono text-[10px] uppercase tracking-widest text-dim">via {a.notes?.includes("VIN") ? "VIN" : "AI assistant"}</span>
                      </div>
                      <p className="mt-2 font-display text-2xl font-bold uppercase text-ink">{a.service}</p>
                      <p className="mt-1 text-sm text-mute">
                        {longDate(a.date)} at {a.time} · {a.vehicleLabel || "Vehicle on file"} · {a.technician || "Technician TBC"}
                        {a.estimate != null && <span className="text-gold"> · est. from {fmtMoney(a.estimate)}</span>}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2.5">
                      {a.conversation.length > 0 && <button onClick={() => setOpenConv(openConv === a.id ? null : a.id)} className="btn-ghost !px-4 !py-2.5 text-[12px]">
                          <Icon name="chat" size={14} /> {openConv === a.id ? "Hide" : "View"} AI chat
                        </button>}
                      {a.status !== "cancelled" && a.status !== "completed" && <>
                          <button onClick={() => setEditAppt(a)} className="btn-ghost !px-4 !py-2.5 text-[12px] !border-racing2/50 !text-racing2 hover:!text-ink">
                            Edit
                          </button>
                          <button onClick={() => setConfirmDelete(a)} className="btn-ghost !px-4 !py-2.5 text-[12px] !border-alert/50 !text-alert hover:!text-ink">
                            Delete
                          </button>
                        </>}
                    </div>
                  </div>
                  {openConv === a.id && <div className="space-y-3 border-t border-line bg-pit/50 p-6">
                      <p className="mono-label mb-2">AI booking transcript · stored with this record</p>
                      {a.conversation.map((m, j) => <div key={j} className={`max-w-[85%] border px-4 py-2.5 text-sm leading-relaxed ${m.role === "user" ? "ml-auto border-lime/25 bg-lime/5 text-ink" : "border-line bg-panel2 text-ink/85"}`}>
                          <span className="mr-2 font-mono text-[9px] uppercase tracking-widest text-dim">{m.role === "user" ? "You" : "Jane"}</span>
                          {m.text}
                        </div>)}
                    </div>}
                </div>
              </Reveal>)}
          </div>}

        {
    /* ---------------- service history ---------------- */
  }
        {tab === "Service history" && <div className="mt-8 overflow-x-auto border border-line">
            <table className="w-full min-w-[760px] text-left text-sm">
              <thead>
                <tr className="border-b border-line bg-pit/60 font-mono text-[10px] uppercase tracking-[0.18em] text-dim">
                  <th className="px-5 py-4">Invoice</th>
                  <th className="px-5 py-4">Date</th>
                  <th className="px-5 py-4">Work performed</th>
                  <th className="px-5 py-4">Vehicle</th>
                  <th className="px-5 py-4">Technician</th>
                  <th className="px-5 py-4 text-right">Amount</th>
                  <th className="px-5 py-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {records.map((r) => <tr key={r.id} className="border-b border-line/60 bg-panel/50 transition-colors hover:bg-panel2">
                    <td className="px-5 py-4 font-mono text-xs text-lime">{r.invoiceNo}</td>
                    <td className="px-5 py-4 text-mute">{labelDate(r.date)}</td>
                    <td className="px-5 py-4 text-ink">{r.title}</td>
                    <td className="px-5 py-4 text-mute">{r.vehicle}</td>
                    <td className="px-5 py-4 text-mute">{r.technician}</td>
                    <td className="px-5 py-4 text-right font-mono text-gold">{fmtMoney(r.cost)}</td>
                    <td className="px-5 py-4 text-right"><Badge status={r.status} /></td>
                  </tr>)}
                {records.length === 0 && <tr><td colSpan={7} className="px-5 py-10 text-center text-mute">No service records yet.</td></tr>}
              </tbody>
            </table>
          </div>}

        {
    /* ---------------- vehicles ---------------- */
  }
        {tab === "Vehicles" && <div className="mt-8 grid gap-8 lg:grid-cols-[420px_1fr]">
            <Reveal>
              <form onSubmit={addVehicle} className="panel h-fit p-7">
                <p className="font-display text-xl font-bold uppercase text-ink">Add vehicle</p>
                <p className="mt-2 text-sm leading-relaxed text-mute">
                  Add a Land Rover to your digital garage. You can delete it later from the vehicle card.
                </p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
                  <label className="block sm:col-span-2 lg:col-span-1">
                    <span className="mono-label">Model</span>
                    <input
    required
    value={vehicleForm.model}
    onChange={(e) => setVehicleForm({ ...vehicleForm, model: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="Range Rover Sport HSE"
  />
                  </label>
                  <label className="block">
                    <span className="mono-label">Year</span>
                    <input
    required
    inputMode="numeric"
    value={vehicleForm.year}
    onChange={(e) => setVehicleForm({ ...vehicleForm, year: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="2024"
  />
                  </label>
                  <label className="block">
                    <span className="mono-label">Mileage</span>
                    <input
    inputMode="numeric"
    value={vehicleForm.mileage}
    onChange={(e) => setVehicleForm({ ...vehicleForm, mileage: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="38200"
  />
                  </label>
                  <label className="block sm:col-span-2 lg:col-span-1">
                    <span className="mono-label">VIN / chassis</span>
                    <input
    required
    value={vehicleForm.vin}
    onChange={(e) => setVehicleForm({ ...vehicleForm, vin: e.target.value.toUpperCase() })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="SAL…"
  />
                  </label>
                  <label className="block">
                    <span className="mono-label">Plate</span>
                    <input
    value={vehicleForm.plate}
    onChange={(e) => setVehicleForm({ ...vehicleForm, plate: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="392841 B"
  />
                  </label>
                  <label className="block">
                    <span className="mono-label">Color</span>
                    <input
    value={vehicleForm.color}
    onChange={(e) => setVehicleForm({ ...vehicleForm, color: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="Santorini Black"
  />
                  </label>
                </div>
                <button type="submit" disabled={vehicleBusy} className="btn-primary mt-6 w-full justify-center disabled:opacity-50">
                  {vehicleBusy ? "Adding\u2026" : "Add vehicle"}
                </button>
              </form>
            </Reveal>

            <div className="grid gap-5 md:grid-cols-2">
              {vehicles.map((v, i) => {
    const bay = bayStatusFor(v);
    return <Reveal key={v.id} delay={i * 90}>
                  <div className="group border border-line bg-panel/70 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-lime/40">
                    <div className="flex items-start justify-between gap-3">
                      <Icon name="lift" size={24} className="text-lime" />
                      <div className="text-right">
                        <span className="block font-mono text-[10px] uppercase tracking-widest text-dim">{v.year}</span>
                        <span className={`mt-2 inline-block border px-2 py-1 font-mono text-[9px] uppercase tracking-widest ${bay.tone}`}>{bay.label}</span>
                      </div>
                    </div>
                    <p className="mt-5 font-display text-2xl font-bold uppercase leading-tight text-ink">{v.model}</p>
                    <p className="mt-1 text-sm text-mute">{v.color || "Color not set"} · {v.plate || "No plate"}</p>
                    <dl className="mt-5 space-y-2 border-t border-line pt-4 font-mono text-[11px] uppercase tracking-widest">
                      <div className="flex justify-between gap-4"><dt className="text-dim">VIN</dt><dd className="truncate text-mute">{v.vin}</dd></div>
                      <div className="flex justify-between"><dt className="text-dim">Odometer</dt><dd className="text-ink">{v.mileage?.toLocaleString() ?? "\u2014"} km</dd></div>
                      <div className="flex justify-between gap-4"><dt className="text-dim">Bay status</dt><dd className="text-right text-ink">{bay.detail}</dd></div>
                    </dl>
                    <button
      onClick={() => deleteVehicle(v)}
      className="mt-5 w-full border border-alert/45 bg-alert/10 px-4 py-2.5 font-mono text-[10px] uppercase tracking-widest text-alert transition-colors hover:bg-alert/20 hover:text-ink"
    >
                      Delete vehicle
                    </button>
                  </div>
                </Reveal>;
  })}
              {vehicles.length === 0 && <div className="border border-line bg-panel/70 p-10 text-center md:col-span-2">
                  <p className="font-display text-2xl font-bold uppercase text-ink">No vehicles yet</p>
                  <p className="mt-2 text-sm text-mute">Add your first Land Rover using the form on the left.</p>
                </div>}
            </div>
          </div>}

        {
    /* ---------------- documents ---------------- */
  }
        {tab === "Documents" && <div className="mt-8 grid gap-8 lg:grid-cols-[360px_1fr]">
            <div className="panel h-fit p-7">
              <p className="font-display text-xl font-bold uppercase text-ink">Upload to your file</p>
              <p className="mt-2 text-sm leading-relaxed text-mute">
                Dashcam clips, damage photos, insurance documents — stored against your vehicles
                and visible to your technician before arrival.
              </p>
              <div className="mt-6 flex gap-2">
                {["photo", "video"].map((k) => <button
    key={k}
    onClick={() => setKind(k)}
    className={`flex-1 border px-4 py-2.5 font-mono text-[11px] uppercase tracking-widest transition-all ${kind === k ? "border-lime bg-lime/10 text-lime" : "border-line2 text-mute hover:text-ink"}`}
  >
                    {k === "photo" ? "\u{1F4F7} Photo" : "\u{1F3AC} Video"}
                  </button>)}
              </div>
              <input
    ref={fileRef}
    type="file"
    accept={kind === "photo" ? "image/*" : "video/*"}
    onChange={(e) => onFile(e.target.files?.[0])}
    className="mt-5 block w-full text-sm text-mute file:mr-4 file:cursor-pointer file:border-0 file:bg-lime file:px-5 file:py-3 file:font-mono file:text-[11px] file:uppercase file:tracking-widest file:text-pit hover:file:bg-[#d8fa74]"
  />
              {uploading && <p className="mono-label mt-4 text-lime">Encrypting & uploading…</p>}
              <p className="mt-4 font-mono text-[9px] uppercase tracking-widest leading-relaxed text-dim">
                Max 8 MB · scanned on upload · encrypted at rest
              </p>
            </div>
            <div>
              <p className="mono-label mb-5">Your vault · {uploads.length} files</p>
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {uploads.map((u) => <figure key={u.id} className="group overflow-hidden border border-line bg-panel/70">
                    {u.kind === "photo" ? <div className="aspect-[4/3] overflow-hidden">
                        <img src={u.url} alt={u.label || "Upload"} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                      </div> : <div className="grid aspect-[4/3] place-items-center bg-pit">
                        <video src={u.url} controls className="h-full w-full object-cover" />
                      </div>}
                    <figcaption className="flex items-center justify-between gap-2 p-4">
                      <span className="truncate text-sm text-ink">{u.label}</span>
                      <span className="shrink-0 font-mono text-[9px] uppercase tracking-widest text-dim">{u.kind}</span>
                    </figcaption>
                  </figure>)}
                {uploads.length === 0 && <p className="text-sm text-mute">Nothing uploaded yet — your vault is empty (and spotless).</p>}
              </div>
            </div>
          </div>}
      </div>

      {editAppt && <EditModal appt={editAppt} onClose={() => setEditAppt(null)} onSaved={() => {
    setEditAppt(null);
    flash("Booking updated \u2014 see you soon.");
    load();
  }} />}
      {confirmDelete && <div className="fixed inset-0 z-[130] grid place-items-center bg-pit/80 p-4 backdrop-blur-sm" role="dialog" aria-modal="true">
          <div className="panel w-full max-w-md p-7">
            <p className="font-display text-2xl font-bold uppercase text-ink">Delete <span className="text-alert">{confirmDelete.refCode}</span>?</p>
            <p className="mt-3 text-sm leading-relaxed text-mute">
              {confirmDelete.service} on {longDate(confirmDelete.date)}. This removes the booking and releases the bay. The AI transcript stays archived for 30 days.
            </p>
            <div className="mt-6 flex gap-3">
              <button onClick={() => setConfirmDelete(null)} className="btn-ghost flex-1 justify-center !py-3 text-sm">Keep it</button>
              <button onClick={doDelete} className="flex-1 border border-alert bg-alert/15 px-5 py-3 font-display text-sm font-bold uppercase tracking-wider text-alert transition-colors hover:bg-alert/25">
                Delete booking
              </button>
            </div>
          </div>
        </div>}
    </section>;
}
function PortalPage() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true);
  useEffect(() => {
    fetch("/api/auth/login").then((r) => r.json()).then((d) => setUser(d.user)).finally(() => setChecking(false));
  }, []);
  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
  };
  if (checking)
    return <section className="grid min-h-[60vh] place-items-center">
        <div className="h-12 w-12 animate-[spinSlow_1.2s_linear_infinite] border border-line2 border-t-lime" />
      </section>;
  return user ? <PortalShell user={user} onLogout={logout} /> : <Login onLogin={setUser} />;
}
export {
  PortalPage as default
};
