"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { Icon, Reveal } from "@/components/fx";
import { fmtMoney, labelDate, STATUS_STYLES } from "@/lib/utils";
const STATUSES = ["pending", "confirmed", "in-service", "awaiting-parts", "completed", "cancelled"];
const emptyStaffForm = {
  name: "",
  role: "Service Advisor",
  specialization: "Owner care \xB7 Land Rover service",
  level: "Certified",
  years: "5",
  rating: "5.0"
};
function Badge({ status }) {
  return <span className={`inline-block border px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.12em] ${STATUS_STYLES[status] || STATUS_STYLES.pending}`}>
      {status}
    </span>;
}
function AdminPage() {
  const [stats, setStats] = useState(null);
  const [rows, setRows] = useState([]);
  const [staff, setStaff] = useState([]);
  const [rowCosts, setRowCosts] = useState({});
  const [filter, setFilter] = useState("all");
  const [staffFilter, setStaffFilter] = useState("all");
  const [flash, setFlash] = useState(null);
  const [staffForm, setStaffForm] = useState(emptyStaffForm);
  const [staffBusy, setStaffBusy] = useState(false);
  const staffPhotoRef = useRef(null);
  const toast = (message) => {
    setFlash(message);
    setTimeout(() => setFlash(null), 2400);
  };
  const load = useCallback(async () => {
    const [s, b, st] = await Promise.all([
      fetch("/api/admin").then((r) => r.json()),
      fetch("/api/admin/bookings").then((r) => r.json()),
      fetch("/api/admin/staff").then((r) => r.json())
    ]);
    const appointments = b.appointments || [];
    setStats(s);
    setRows(appointments);
    setRowCosts(Object.fromEntries(appointments.map((a) => [a.id, a.estimate == null ? "" : String(a.estimate)])));
    setStaff(st.staff || []);
  }, []);
  useEffect(() => {
    load();
  }, [load]);
  const patch = async (id, patchBody) => {
    const res = await fetch("/api/admin/bookings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...patchBody })
    });
    const data = await res.json().catch(() => ({}));
    if (res.ok) {
      toast(`Saved \u2014 ${patchBody.status || patchBody.technician || patchBody.cost || "updated"}`);
      load();
    } else {
      toast(data.error || "Could not update appointment.");
    }
  };
  const saveCost = async (row) => {
    const next = (rowCosts[row.id] ?? "").trim();
    const current = row.estimate == null ? "" : String(row.estimate);
    if (next !== current) await patch(row.id, { cost: next });
  };
  const patchStatus = async (row, status) => {
    const cost = (rowCosts[row.id] ?? "").trim();
    await patch(row.id, { status, ...status === "completed" || cost ? { cost } : {} });
  };
  const deleteAppointment = async (row) => {
    if (!confirm(`Delete appointment ${row.ref_code}? This removes it from the workshop board.`)) return;
    const res = await fetch(`/api/admin/bookings?id=${row.id}`, { method: "DELETE" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return toast(data.error || "Could not delete appointment.");
    toast(`Deleted \u2014 ${row.ref_code}`);
    load();
  };
  const createStaff = async (e) => {
    e.preventDefault();
    setStaffBusy(true);
    const fd = new FormData();
    Object.entries(staffForm).forEach(([k, v]) => fd.append(k, v));
    const file = staffPhotoRef.current?.files?.[0];
    if (file) fd.append("photo", file);
    const res = await fetch("/api/admin/staff", { method: "POST", body: fd });
    const data = await res.json().catch(() => ({}));
    setStaffBusy(false);
    if (!res.ok) return toast(data.error || "Could not create staff member.");
    setStaffForm(emptyStaffForm);
    if (staffPhotoRef.current) staffPhotoRef.current.value = "";
    toast(`Staff added \u2014 ${data.staff?.name || staffForm.name}`);
    load();
  };
  const deleteStaff = async (member) => {
    if (!confirm(`Delete ${member.name}? Their assigned appointments will become unassigned.`)) return;
    const res = await fetch(`/api/admin/staff?id=${member.id}`, { method: "DELETE" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return toast(data.error || "Could not delete staff member.");
    if (staffFilter === member.name) setStaffFilter("all");
    toast(`Deleted \u2014 ${member.name}`);
    load();
  };
  const staffCounts = new Map((stats?.technicians ?? []).map((t) => [t.name, t.count]));
  const staffWithAssignedOnly = (stats?.technicians ?? []).filter((t) => !staff.some((s) => s.name === t.name)).map((t) => ({ id: -Math.abs(t.name.length), name: t.name, role: "Assigned only", specialization: "Existing appointment assignment", level: null, years: null, rating: null, avatar: null }));
  const staffRoster = [...staff, ...staffWithAssignedOnly];
  const visible = rows.filter(
    (r) => (filter === "all" || r.status === filter) && (staffFilter === "all" || r.technician === staffFilter)
  );
  const maxRev = Math.max(...stats?.revenue.map((r) => r.total) ?? [1], 1);
  const maxTech = Math.max(...staffRoster.map((s) => staffCounts.get(s.name) || 0), 1);
  const insights = stats ? [
    { icon: "bolt", text: `AI assistant captured ${stats.aiBookings} bookings \u2014 conversion is strong; keep Jane visible.` },
    { icon: "calendar", text: `${stats.todayJobs} jobs on today's sheet. Tap staff names to filter the appointments board.` },
    { icon: "doc", text: "Enter cost before completion \u2014 the transaction posts to Service History automatically." },
    { icon: "gauge", text: "Completed rows become digital service records with invoice numbers tied to the appointment reference." }
  ] : [];
  return <section className="relative min-h-[calc(100vh-97px)]">
      <div className="carbon absolute inset-0 opacity-30" aria-hidden />
      {flash && <div className="anim-rise fixed left-1/2 top-24 z-[140] -translate-x-1/2 border border-lime/50 bg-pit px-5 py-3 font-mono text-xs uppercase tracking-widest text-lime">
          {flash}
        </div>}
      <div className="relative mx-auto max-w-[1500px] px-4 py-12 md:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="mono-label mb-3 flex items-center gap-3">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime pulse-dot" /> Workshop OS · live floor control
            </p>
            <h1 className="font-display text-6xl font-bold uppercase leading-none text-ink md:text-7xl">
              Mission <span className="text-lime">control</span>
            </h1>
          </div>
          <div className="flex flex-col items-start gap-3 md:items-end">
            <div className="border border-line2 bg-panel/50 px-5 py-3 font-display text-sm font-bold uppercase tracking-[0.12em] text-ink">
              <span className="inline-flex items-center gap-3"><Icon name="chip" size={16} className="text-lime" /> Workshop OS</span>
            </div>
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-dim">RBAC: admin · staff CRUD · cost posting</p>
          </div>
        </div>

        {!stats ? <div className="mt-24 grid place-items-center">
            <div className="h-12 w-12 animate-[spinSlow_1.2s_linear_infinite] border border-line2 border-t-lime" />
          </div> : <>
            <div className="mt-10 grid grid-cols-2 gap-px border border-line bg-line lg:grid-cols-4">
              {[
    { k: "Jobs today", v: String(stats.todayJobs), sub: "bay schedule" },
    { k: "AI-captured bookings", v: String(stats.aiBookings), sub: "via Jane" },
    { k: "Staff on roster", v: String(staff.length), sub: "create / delete / upload" },
    { k: "12-month revenue", v: fmtMoney(stats.totalRevenue), sub: `${stats.totalRecords} invoices` }
  ].map((s, i) => <div key={s.k} className="bg-panel px-6 py-7">
                  <p className="mono-label">{s.k}</p>
                  <p className="mt-3 font-display text-4xl font-bold text-ink md:text-5xl">{s.v}</p>
                  <p className="mt-1.5 font-mono text-[10px] uppercase tracking-widest text-dim">{s.sub}</p>
                  <span className="mt-4 block h-0.5 bg-lime transition-all duration-700" style={{ width: `${25 + i * 22}%` }} />
                </div>)}
            </div>

            <div className="mt-8 grid gap-8 xl:grid-cols-[1.5fr_1fr]">
              <Reveal>
                <div className="h-full border border-line bg-panel/70 p-7">
                  <div className="mb-6 flex items-center justify-between">
                    <p className="font-display text-xl font-bold uppercase text-ink">Revenue — trailing months</p>
                    <span className="font-mono text-[10px] uppercase tracking-widest text-dim">service records</span>
                  </div>
                  <div className="flex h-48 items-end gap-2 md:gap-3">
                    {stats.revenue.map((r, i) => <div key={i} className="group flex h-full flex-1 flex-col items-center justify-end gap-2">
                        <span className="font-mono text-[9px] text-dim opacity-0 transition-opacity group-hover:opacity-100">{fmtMoney(r.total)}</span>
                        <div className="w-full bg-gradient-to-t from-racing to-racing2 transition-all duration-500 group-hover:from-lime group-hover:to-lime" style={{ height: `${Math.max(r.total / maxRev * 100, 3)}%` }} />
                        <span className="font-mono text-[9px] uppercase tracking-widest text-dim">{r.mon}</span>
                      </div>)}
                  </div>
                </div>
              </Reveal>

              <div className="space-y-8">
                <Reveal delay={100}>
                  <div className="border border-line bg-panel/70 p-7">
                    <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
                      <p className="font-display text-xl font-bold uppercase text-ink">Technician load</p>
                      {staffFilter !== "all" && <button onClick={() => setStaffFilter("all")} className="font-mono text-[10px] uppercase tracking-widest text-lime hover:text-ink">Clear staff filter</button>}
                    </div>
                    <div className="space-y-4">
                      {staffRoster.map((member) => {
    const count = staffCounts.get(member.name) || 0;
    const selected = staffFilter === member.name;
    return <button key={member.id + member.name} onClick={() => setStaffFilter(selected ? "all" : member.name)} className="block w-full text-left">
                            <div className="mb-1.5 flex justify-between gap-3 text-sm">
                              <span className={selected ? "text-lime" : "text-ink"}>{member.name}</span>
                              <span className="font-mono text-[10px] uppercase tracking-widest text-dim">{count} jobs</span>
                            </div>
                            <div className="h-1.5 w-full bg-raise"><div className="h-full bg-lime transition-all duration-700" style={{ width: `${count / maxTech * 100}%` }} /></div>
                          </button>;
  })}
                    </div>
                  </div>
                </Reveal>
                <Reveal delay={180}>
                  <div className="border border-lime/25 bg-lime/5 p-7">
                    <p className="mono-label mb-4 flex items-center gap-2 text-lime"><span className="h-1.5 w-1.5 rounded-full bg-lime pulse-dot" /> AI admin assistant — live insights</p>
                    <ul className="space-y-3.5">
                      {insights.map((ins, i) => <li key={i} className="flex gap-3 text-sm leading-relaxed text-mute"><Icon name={ins.icon} size={16} className="mt-0.5 shrink-0 text-lime" />{ins.text}</li>)}
                    </ul>
                  </div>
                </Reveal>
              </div>
            </div>

            <div className="mt-12 grid gap-8 xl:grid-cols-[1.3fr_0.7fr]">
              <Reveal>
                <div className="border border-line bg-panel/70 p-7">
                  <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
                    <div><p className="font-display text-2xl font-bold uppercase text-ink">Staff list</p><p className="mt-1 text-sm text-mute">Click a staff name to filter Technician Load + Appointments Board.</p></div>
                    <button onClick={() => setStaffFilter("all")} className="chip">All staff</button>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                    {staff.map((member) => {
    const count = staffCounts.get(member.name) || 0;
    const selected = staffFilter === member.name;
    return <article key={member.id} className={`group border p-4 transition-all duration-300 ${selected ? "border-lime bg-lime/5" : "border-line bg-pit/40 hover:border-line2"}`}>
                          <button onClick={() => setStaffFilter(selected ? "all" : member.name)} className="flex w-full items-center gap-4 text-left">
                            <img src={member.avatar || "/images/hero-poster.jpg"} alt={member.name} onError={(e) => {
      e.currentTarget.onerror = null;
      e.currentTarget.src = "/images/hero-poster.jpg";
    }} className="h-16 w-16 shrink-0 border border-line2 object-cover grayscale-[25%]" />
                            <span className="min-w-0"><span className={`block truncate font-display text-lg font-bold uppercase ${selected ? "text-lime" : "text-ink"}`}>{member.name}</span><span className="mt-0.5 block truncate font-mono text-[10px] uppercase tracking-widest text-dim">{member.role}</span><span className="mt-1 block text-xs text-mute">{member.specialization}</span></span>
                          </button>
                          <div className="mt-4 flex items-center justify-between border-t border-line pt-3"><span className="font-mono text-[10px] uppercase tracking-widest text-dim">{count} linked jobs</span><button onClick={() => deleteStaff(member)} className="font-mono text-[10px] uppercase tracking-widest text-alert transition-colors hover:text-ink">Delete</button></div>
                        </article>;
  })}
                  </div>
                </div>
              </Reveal>

              <Reveal delay={120}>
                <form onSubmit={createStaff} className="border border-line bg-panel/70 p-7">
                  <p className="font-display text-xl font-bold uppercase text-ink">Create staff data</p>
                  <p className="mt-1 text-sm text-mute">Add a technician/advisor and upload their photo.</p>
                  <div className="mt-5 space-y-4">
                    <label className="block"><span className="mono-label">Name</span><input required value={staffForm.name} onChange={(e) => setStaffForm({ ...staffForm, name: e.target.value })} className="mt-2 w-full border border-line2 bg-pit px-3 py-2.5 text-sm text-ink focus:border-lime/60 focus:outline-none" placeholder="Johnny Baydoun" /></label>
                    <label className="block"><span className="mono-label">Role</span><input value={staffForm.role} onChange={(e) => setStaffForm({ ...staffForm, role: e.target.value })} className="mt-2 w-full border border-line2 bg-pit px-3 py-2.5 text-sm text-ink focus:border-lime/60 focus:outline-none" /></label>
                    <label className="block"><span className="mono-label">Specialization</span><input value={staffForm.specialization} onChange={(e) => setStaffForm({ ...staffForm, specialization: e.target.value })} className="mt-2 w-full border border-line2 bg-pit px-3 py-2.5 text-sm text-ink focus:border-lime/60 focus:outline-none" /></label>
                    <div className="grid grid-cols-3 gap-3">
                      <label className="block"><span className="mono-label">Level</span><input value={staffForm.level} onChange={(e) => setStaffForm({ ...staffForm, level: e.target.value })} className="mt-2 w-full border border-line2 bg-pit px-3 py-2.5 text-sm text-ink focus:border-lime/60 focus:outline-none" /></label>
                      <label className="block"><span className="mono-label">Years</span><input value={staffForm.years} onChange={(e) => setStaffForm({ ...staffForm, years: e.target.value })} className="mt-2 w-full border border-line2 bg-pit px-3 py-2.5 text-sm text-ink focus:border-lime/60 focus:outline-none" /></label>
                      <label className="block"><span className="mono-label">Rating</span><input value={staffForm.rating} onChange={(e) => setStaffForm({ ...staffForm, rating: e.target.value })} className="mt-2 w-full border border-line2 bg-pit px-3 py-2.5 text-sm text-ink focus:border-lime/60 focus:outline-none" /></label>
                    </div>
                    <label className="block"><span className="mono-label">Upload photo</span><input ref={staffPhotoRef} type="file" accept="image/*" className="mt-2 block w-full text-xs text-mute file:mr-3 file:cursor-pointer file:border-0 file:bg-lime file:px-4 file:py-2.5 file:font-mono file:text-[10px] file:uppercase file:tracking-widest file:text-pit hover:file:bg-[#d8fa74]" /></label>
                    <button type="submit" disabled={staffBusy} className="btn-primary w-full justify-center !py-3 text-sm disabled:opacity-50">{staffBusy ? "Creating\u2026" : "Create staff"}</button>
                  </div>
                </form>
              </Reveal>
            </div>

            <div className="mt-12">
              <div className="mb-5 flex flex-wrap items-center justify-between gap-4"><div><p className="font-display text-2xl font-bold uppercase text-ink">Appointments board</p><p className="mt-1 text-sm text-mute">Enter cost manually before marking completed. Completed jobs are registered in Service History automatically.</p>{staffFilter !== "all" && <p className="mt-1 text-sm text-mute">Filtered by staff: <span className="text-lime">{staffFilter}</span></p>}</div><div className="flex flex-wrap gap-2">{["all", ...STATUSES].map((s) => <button key={s} onClick={() => setFilter(s)} className={`px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest transition-all ${filter === s ? "bg-lime text-pit" : "border border-line2 text-mute hover:text-ink"}`}>{s}</button>)}</div></div>
              <div className="overflow-x-auto border border-line">
                <table className="w-full min-w-[1050px] text-left text-sm"><thead><tr className="border-b border-line bg-pit/60 font-mono text-[10px] uppercase tracking-[0.16em] text-dim"><th className="px-4 py-3.5">Ref</th><th className="px-4 py-3.5">When</th><th className="px-4 py-3.5">Customer / vehicle</th><th className="px-4 py-3.5">Service</th><th className="px-4 py-3.5">Technician</th><th className="px-4 py-3.5">Cost</th><th className="px-4 py-3.5">Status</th><th className="px-4 py-3.5 text-right">Source</th><th className="px-4 py-3.5 text-right">Actions</th></tr></thead>
                  <tbody>
                    {visible.map((r) => <tr key={r.id} className="border-b border-line/60 bg-panel/50 transition-colors hover:bg-panel2">
                        <td className="px-4 py-3.5 font-mono text-xs text-lime">{r.ref_code}{r.conversation && <span className="ml-2 inline-block border border-line2 px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-widest text-dim">AI log</span>}</td>
                        <td className="px-4 py-3.5 text-mute">{labelDate(r.date)} · {r.time}</td>
                        <td className="px-4 py-3.5"><span className="text-ink">{r.customer_name || "\u2014"}</span><span className="block text-xs text-dim">{r.vehicle_label || "\u2014"}</span></td>
                        <td className="px-4 py-3.5 text-ink">{r.service}</td>
                        <td className="px-4 py-3.5"><select value={r.technician || ""} onChange={(e) => patch(r.id, { technician: e.target.value })} className="border border-line2 bg-pit px-2 py-1.5 text-xs text-ink focus:border-lime/60 focus:outline-none"><option value="">Unassigned</option>{staff.map((member) => <option key={member.id} value={member.name}>{member.name}</option>)}</select></td>
                        <td className="px-4 py-3.5"><input type="number" min="0" step="1" value={rowCosts[r.id] ?? ""} placeholder="Cost" onChange={(e) => setRowCosts((prev) => ({ ...prev, [r.id]: e.target.value }))} onBlur={() => saveCost(r)} onKeyDown={(e) => {
    if (e.key === "Enter") e.currentTarget.blur();
  }} className="w-28 border border-line2 bg-pit px-2 py-1.5 text-xs text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none" /></td>
                        <td className="px-4 py-3.5"><div className="flex items-center gap-2"><Badge status={r.status} /><select value={r.status} onChange={(e) => patchStatus(r, e.target.value)} className="border border-line2 bg-pit px-2 py-1.5 text-xs text-ink focus:border-lime/60 focus:outline-none">{STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}</select></div></td>
                        <td className="px-4 py-3.5 text-right font-mono text-[10px] uppercase tracking-widest text-dim">{r.source}</td>
                        <td className="px-4 py-3.5 text-right"><button onClick={() => deleteAppointment(r)} className="border border-alert/45 bg-alert/10 px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest text-alert transition-colors hover:bg-alert/20 hover:text-ink">Delete</button></td>
                      </tr>)}
                    {visible.length === 0 && <tr><td colSpan={9} className="px-4 py-10 text-center text-mute">No appointments in this view.</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-10 flex flex-wrap gap-3">{stats.statuses.map((s) => <span key={s.status} className="border border-line bg-panel/60 px-4 py-2.5 font-mono text-[11px] uppercase tracking-widest text-mute"><span className="text-ink">{s.c}</span> × {s.status}</span>)}</div>
          </>}
      </div>
    </section>;
}
export {
  AdminPage as default
};
