"use client";
import { useState } from "react";
import Link from "next/link";
import { Icon, Reveal, Scramble } from "@/components/fx";
const FAQS = [
  { q: "How often should my Land Rover be serviced?", a: "Every 12 months or 16,000 km, whichever comes first. For severe duty \u2014 desert heat, towing, repeated short trips \u2014 we move that to 10,000 km. Your duty cycle is recorded in your digital vehicle passport and the reminder adapts." },
  { q: "Do you use genuine parts?", a: "Only genuine JLR parts or approved OE equivalents (Wabco, ZF, Brembo) where the component is identical to the factory part. Every part is serial-traced and logged against your VIN." },
  { q: "What warranty do repairs carry?", a: "24 months on drivetrain and air-suspension work, 12 months on most mechanical repairs, and the manufacturer's term on genuine parts. It's printed on every job card \u2014 no verbal promises." },
  { q: "My Range Rover is sagging overnight. Can I drive it?", a: "Short answer: carefully, and not for long. A sagging corner usually means a leaking air spring, and the compressor is compensating all night \u2014 that's what burns it out next. Book within 48 hours; Jane can triage the exact corner in chat." },
  { q: "Can you handle hybrids and the P400e?", a: "Yes \u2014 our HV bay is staffed by IMI Level 4 technicians with insulated tooling and cell-level diagnostics. We repair battery modules rather than quoting whole packs whenever engineering allows." },
  { q: "Do you offer pickup, delivery or a courtesy car?", a: "Covered recovery runs 07:00\u201322:00, flatbed transport is complimentary for booked repairs, and courtesy Defenders/Discoveries are available for jobs over two days. Ask Jane to add one while booking." },
  { q: "How do recalls work?", a: "Paste your VIN to Jane and she runs an open-recall check against the JLR campaign database. Recall work is performed free of charge, exactly as the factory specifies." },
  { q: "How is diagnostic pricing handled?", a: "Every diagnostic is quoted by a service advisor before work begins, then documented with a photo report and technician notes. You approve the next step only after the cause is confirmed." },
  { q: "Can I watch my repair happen?", a: "The owner portal shows a live status timeline with technician notes at each stage, plus photos at key moments. Many owners tell us it's mildly addictive." },
  { q: "Do you work on classic Land Rovers?", a: "The restoration wing does exactly that \u2014 chassis, drivetrain and body rebuilds to concours standard, documented with a full photographic build log. Commission slots open twice a year." }
];
function FaqPage() {
  const [open, setOpen] = useState(0);
  return <>
      <section className="relative overflow-hidden border-b border-line">
        <div className="carbon absolute inset-0 opacity-50" aria-hidden />
        <div className="relative mx-auto max-w-[1400px] px-4 pb-16 pt-20 md:px-8">
          <p className="mono-label mb-6 flex items-center gap-3">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime pulse-dot" /> AI knowledge center
          </p>
          <h1 className="font-display text-6xl font-bold uppercase leading-[0.88] text-ink md:text-8xl">
            <Scramble text="Questions," /> <span className="text-outline"><Scramble text="answered straight" delay={200} /></span>
          </h1>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-mute">
            The ten questions every Land Rover owner asks — answered the way we'd answer a friend.
            For anything else, Jane is awake right now.
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-[1400px] gap-14 px-4 py-16 md:px-8 lg:grid-cols-[1.4fr_1fr]">
        <div>
          {FAQS.map((f, i) => <Reveal key={f.q} delay={Math.min(i * 50, 250)}>
              <div className={`border-b border-line transition-colors ${open === i ? "bg-panel/40" : ""}`}>
                <button
    onClick={() => setOpen(open === i ? -1 : i)}
    aria-expanded={open === i}
    className="flex w-full items-center justify-between gap-6 px-2 py-6 text-left"
  >
                  <span className="flex items-baseline gap-4">
                    <span className="font-mono text-xs tracking-widest text-lime">{String(i + 1).padStart(2, "0")}</span>
                    <span className={`font-display text-xl font-semibold uppercase tracking-wide transition-colors md:text-2xl ${open === i ? "text-lime" : "text-ink"}`}>
                      {f.q}
                    </span>
                  </span>
                  <span className={`grid h-9 w-9 shrink-0 place-items-center border border-line2 transition-all duration-300 ${open === i ? "rotate-45 border-lime text-lime" : "text-mute"}`}>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M7 1v12M1 7h12" /></svg>
                  </span>
                </button>
                <div className={`grid transition-all duration-500 ${open === i ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}>
                  <div className="min-h-0 overflow-hidden">
                    <p className="max-w-2xl px-2 pb-7 pl-[52px] text-base leading-relaxed text-mute">{f.a}</p>
                  </div>
                </div>
              </div>
            </Reveal>)}
        </div>
        <aside className="space-y-6">
          <div className="panel p-7">
            <p className="mono-label mb-4 text-lime">Still curious?</p>
            <p className="font-display text-2xl font-bold uppercase leading-tight text-ink">
              Jane answers in <span className="text-lime">~2 seconds</span>
            </p>
            <p className="mt-3 text-sm leading-relaxed text-mute">
              Maintenance schedules, recall checks, cost bands, availability — the whole knowledge
              base lives in the assistant.
            </p>
            <Link href="/assistant" className="btn-primary mt-6 w-full justify-center">
              <Icon name="chat" size={16} /> Ask Jane
            </Link>
          </div>
          <div className="border border-line bg-panel/60 p-7">
            <p className="mono-label mb-4">Popular right now</p>
            <ul className="space-y-3">
              {["Air suspension warning at 60k km", "ZF fluid service interval", "Pivi Pro black-screen fix", 'Defender 2" lift legality'].map((t) => <li key={t}>
                  <Link href={`/assistant`} className="group flex items-center justify-between gap-3 text-sm text-mute transition-colors hover:text-lime">
                    {t}
                    <Icon name="arrow" size={14} className="transition-transform duration-300 group-hover:translate-x-1" />
                  </Link>
                </li>)}
            </ul>
          </div>
        </aside>
      </section>
    </>;
}
export {
  FaqPage as default
};
