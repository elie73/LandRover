"use client";
import { useState } from "react";
import { WORKSHOP } from "@/lib/services";
import { Icon, Reveal, Scramble } from "@/components/fx";
function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "General enquiry", message: "" });
  const [err, setErr] = useState(null);
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setErr(d.error || "Could not send \u2014 try WhatsApp instead.");
    setSent(true);
  };
  return <>
      <section className="relative overflow-hidden border-b border-line">
        <div className="carbon absolute inset-0 opacity-50" aria-hidden />
        <div className="relative mx-auto max-w-[1400px] px-4 pb-16 pt-20 md:px-8">
          <p className="mono-label mb-6 flex items-center gap-3">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime pulse-dot" /> We answer within the hour, opening times
          </p>
          <h1 className="font-display text-6xl font-bold uppercase leading-[0.88] text-ink md:text-8xl">
            <Scramble text="Talk to" /> <span className="text-lime"><Scramble text="the atelier" delay={200} /></span>
          </h1>
        </div>
      </section>

      <section className="mx-auto grid max-w-[1400px] gap-12 px-4 py-16 md:px-8 lg:grid-cols-[1fr_1.2fr]">
        <div className="space-y-6">
          <Reveal>
            <div className="panel p-7">
              <p className="mono-label mb-5">Direct lines</p>
              <ul className="space-y-5">
                {[
    { icon: "pin", k: "The atelier", v: WORKSHOP.address, href: null, accent: false },
    { icon: "phone", k: "Phone", v: WORKSHOP.phone, href: `tel:${WORKSHOP.phone.replace(/\s/g, "")}`, accent: false },
    { icon: "whatsapp", k: "WhatsApp", v: WORKSHOP.whatsapp, href: WORKSHOP.whatsappLink, accent: true },
    { icon: "doc", k: "Email", v: WORKSHOP.email, href: `mailto:${WORKSHOP.email}`, accent: false }
  ].map((row) => <li key={row.k} className="flex gap-4">
                    <span className={`grid h-11 w-11 shrink-0 place-items-center border ${row.accent ? "border-[#25d366]/50 text-[#25d366]" : "border-line2 text-lime"}`}>
                      <Icon name={row.icon} size={18} />
                    </span>
                    <div>
                      <p className="mono-label !text-[9px]">{row.k}</p>
                      {row.href ? <a
    href={row.href}
    target={row.accent ? "_blank" : void 0}
    rel={row.accent ? "noreferrer" : void 0}
    className={`mt-1 block text-sm transition-colors hover:underline underline-offset-4 ${row.accent ? "text-[#25d366]" : "text-ink hover:text-lime"}`}
  >
                          {row.v}
                        </a> : <p className="mt-1 text-sm text-ink">{row.v}</p>}
                    </div>
                  </li>)}
              </ul>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div className="border border-line bg-panel/60 p-7">
              <p className="mono-label mb-4">Opening hours</p>
              <ul className="space-y-2.5">
                {WORKSHOP.hoursDetail.map(([d, h]) => <li key={d} className="flex justify-between text-sm">
                    <span className="text-mute">{d}</span>
                    <span className="font-mono text-xs uppercase tracking-widest text-ink">{h}</span>
                  </li>)}
              </ul>
              <p className="mt-5 border-t border-line pt-4 text-xs leading-relaxed text-dim">
                Recovery line 07:00–22:00, seven days. For bookings, Jane never sleeps.
              </p>
            </div>
          </Reveal>
          <Reveal delay={160}>
            <div className="gridlines relative overflow-hidden border border-line">
              <iframe
    title="Workshop location map"
    src={WORKSHOP.mapEmbed}
    className="h-64 w-full grayscale invert-[0.92] contrast-[0.9] hue-rotate-[120deg]"
    loading="lazy"
  />
              <a
    href={WORKSHOP.mapUrl}
    target="_blank"
    rel="noreferrer"
    className="absolute bottom-3 right-3 border border-lime/50 bg-pit/80 px-3 py-2 font-mono text-[10px] uppercase tracking-widest text-lime backdrop-blur transition-colors hover:bg-lime hover:text-pit"
  >
                Open in Maps ↗
              </a>
            </div>
          </Reveal>
        </div>

        <Reveal delay={120}>
          <form onSubmit={submit} className="panel relative overflow-hidden p-8 md:p-10">
            <div className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-racing via-lime to-racing" />
            <p className="font-display text-3xl font-bold uppercase text-ink">Send a message</p>
            <p className="mt-2 text-sm text-mute">Fleet enquiries, restoration commissions, press, careers — all read by a human.</p>
            {sent ? <div className="mt-8 border border-lime/40 bg-lime/10 p-6 text-center">
                <p className="font-display text-2xl font-bold uppercase text-lime">Message received ✓</p>
                <p className="mt-2 text-sm text-mute">A service advisor will reply within the hour during opening times.</p>
              </div> : <div className="mt-7 grid gap-5 sm:grid-cols-2">
                <label className="block">
                  <span className="mono-label">Name</span>
                  <input
    required
    value={form.name}
    onChange={(e) => setForm({ ...form, name: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="Your name"
  />
                </label>
                <label className="block">
                  <span className="mono-label">Email</span>
                  <input
    type="email"
    value={form.email}
    onChange={(e) => setForm({ ...form, email: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="you@example.com"
  />
                </label>
                <label className="block">
                  <span className="mono-label">Phone</span>
                  <input
    value={form.phone}
    onChange={(e) => setForm({ ...form, phone: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="+961 …"
  />
                </label>
                <label className="block">
                  <span className="mono-label">Subject</span>
                  <select
    value={form.subject}
    onChange={(e) => setForm({ ...form, subject: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink focus:border-lime/60 focus:outline-none"
  >
                    {["General enquiry", "Fleet & corporate", "Restoration commission", "Insurance repair", "Careers", "Press"].map((s) => <option key={s}>{s}</option>)}
                  </select>
                </label>
                <label className="block sm:col-span-2">
                  <span className="mono-label">Message</span>
                  <textarea
    required
    rows={5}
    value={form.message}
    onChange={(e) => setForm({ ...form, message: e.target.value })}
    className="mt-2 w-full resize-none border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="Tell us about the vehicle, the issue, or the project…"
  />
                </label>
                {err && <p className="border border-alert/40 bg-alert/10 px-3 py-2.5 text-sm text-alert sm:col-span-2">{err}</p>}
                <div className="sm:col-span-2">
                  <button type="submit" disabled={busy} className="btn-primary w-full justify-center disabled:opacity-50">
                    {busy ? "Sending\u2026" : "Send to the atelier"}
                  </button>
                </div>
              </div>}
          </form>
        </Reveal>
      </section>
    </>;
}
export {
  ContactPage as default
};
