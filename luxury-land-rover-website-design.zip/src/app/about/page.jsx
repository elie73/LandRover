import { Icon, Reveal, Scramble, SectionHead } from "@/components/fx";
import Link from "next/link";
const TECHS = [
  { name: "Karim Haddad", role: "Head of Workshop", spec: "Air suspension \xB7 EAS calibration", years: 24, rating: "4.9", img: "https://images.pexels.com/photos/7564867/pexels-photo-7564867.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800" },
  { name: "Elias Mroueh", role: "Master Technician", spec: "Driveline \xB7 ZF transmissions", years: 18, rating: "4.9", img: "https://images.pexels.com/photos/6720496/pexels-photo-6720496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800" },
  { name: "Dany Khoury", role: "Diagnostics Lead", spec: "Electrical \xB7 CAN forensics", years: 14, rating: "4.8", img: "https://images.pexels.com/photos/4489774/pexels-photo-4489774.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800" },
  { name: "Sami Najjar", role: "Performance Engineer", spec: "ECU calibration \xB7 dyno", years: 11, rating: "4.8", img: "https://images.pexels.com/photos/28153670/pexels-photo-28153670.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800" },
  { name: "Tarek Ayoub", role: "Service Technician", spec: "Servicing \xB7 brakes \xB7 chassis", years: 8, rating: "4.7", img: "https://images.pexels.com/photos/4481952/pexels-photo-4481952.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800" }
];
const TIMELINE = [
  ["1996", "A two-bay garage and a Series III toolbox. First customer: a farmer's 1972 88-inch."],
  ["2004", "Became fully independent Land Rover-only. Turned away every non-Solihull car since."],
  ["2012", "First JLR Pathfinder suite in the country. Master technician programme launched."],
  ["2019", "Restoration wing opens \u2014 the Classic 90 programme sells out its first year."],
  ["2023", "Jane, our AI service assistant, goes live. Bookings answered in under 2 seconds, 24/7."],
  ["2025", "Eight bays, fourteen technicians, one standard. 12,480 vehicles and counting."]
];
const CERTS = [
  ["JLR Certified Technicians", "Factory-trained & assessed annually"],
  ["IMI Level 4 High Voltage", "Certified for P400e & EV systems"],
  ["ZF Transmission Certified", "Approved 8HP rebuild centre"],
  ["ISO 9001:2015", "Audited quality management"]
];
function AboutPage() {
  return <>
      <section className="relative overflow-hidden border-b border-line">
        <div className="carbon absolute inset-0 opacity-50" aria-hidden />
        <div className="glow-racing pointer-events-none absolute -top-32 left-1/3 h-[420px] w-[620px]" aria-hidden />
        <div className="relative mx-auto max-w-[1400px] px-4 pb-16 pt-20 md:px-8">
          <p className="mono-label mb-6 flex items-center gap-3">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime pulse-dot" /> Est. 1996 · Land Rover only, forever
          </p>
          <h1 className="max-w-5xl font-display text-6xl font-bold uppercase leading-[0.88] text-ink md:text-8xl">
            <Scramble text="Twenty-eight years." />
            <br />
            <span className="text-outline"><Scramble text="One obsession." delay={250} /></span>
          </h1>
        </div>
      </section>

      {
    /* story */
  }
      <section className="mx-auto max-w-[1400px] px-4 py-20 md:px-8 md:py-28">
        <div className="grid items-start gap-14 lg:grid-cols-2">
          <div>
            <SectionHead kicker="The story" title={<>Built by people who<br /><span className="text-lime">heard the rattle first</span></>} />
            <Reveal delay={120}>
              <div className="max-w-xl space-y-5 text-base leading-relaxed text-mute">
                <p>
                  Baydoun started the way all honest workshops do: a Land Rover that nobody else
                  could fix, and a stubborn refusal to accept “that's just what they do.” Twenty-eight
                  years later we still take the cars other garages give up on — and we still call
                  the owner the moment we hear something we don't like.
                </p>
                <p>
                  Today the atelier runs eight bays, a high-voltage suite, a dyno cell and a
                  restoration wing. But the ritual hasn't changed: every vehicle gets a master
                  technician's ears before it gets a computer's opinion.
                </p>
              </div>
            </Reveal>
            <Reveal delay={220}>
              <div className="mt-10 grid grid-cols-2 gap-px border border-line bg-line">
                {CERTS.map(([t, d]) => <div key={t} className="group bg-panel p-5 transition-colors hover:bg-panel2">
                    <Icon name="shield" size={20} className="text-lime" />
                    <p className="mt-3 font-display text-base font-semibold uppercase tracking-wide text-ink">{t}</p>
                    <p className="mt-1 text-xs text-mute">{d}</p>
                  </div>)}
              </div>
            </Reveal>
          </div>
          <div>
            <Reveal delay={150}>
              <div className="relative overflow-hidden border border-line" data-mag>
                <img src="/images/workshop.jpg" alt="The Baydoun atelier floor" className="anim-kenburns block aspect-[4/5] w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-pit via-transparent to-transparent" />
                <p className="absolute bottom-5 left-5 font-mono text-[10px] uppercase tracking-[0.22em] text-lime">Bay 03 · 06:41 · first lift of the day</p>
              </div>
            </Reveal>
          </div>
        </div>

        {
    /* timeline */
  }
        <div className="mt-24">
          <SectionHead kicker="Milestones" title={<>The road<br /><span className="text-outline">so far</span></>} />
          <div className="relative ml-3 border-l border-line2 pl-8 md:ml-6 md:pl-12">
            {TIMELINE.map(([year, text], i) => <Reveal key={year} delay={i * 90}>
                <div className="relative pb-10 last:pb-0">
                  <span className="absolute -left-[41px] top-1 grid h-5 w-5 place-items-center bg-bg md:-left-[57px]">
                    <span className="h-2.5 w-2.5 rotate-45 border border-lime bg-pit" />
                  </span>
                  <p className="font-display text-3xl font-bold text-lime">{year}</p>
                  <p className="mt-2 max-w-xl text-base leading-relaxed text-mute">{text}</p>
                </div>
              </Reveal>)}
          </div>
        </div>
      </section>

      {
    /* technicians */
  }
      <section className="border-t border-line bg-pit/50 py-20 md:py-28">
        <div className="mx-auto max-w-[1400px] px-4 md:px-8">
          <SectionHead
    kicker="Meet the bench"
    title={<>Master<br /><span className="text-lime">technicians</span></>}
    right={<p className="max-w-xs text-sm leading-relaxed text-mute">14 certified hands on the floor. These are the five your car is most likely to meet.</p>}
  />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
            {TECHS.map((t, i) => <Reveal key={t.name} delay={i * 80}>
                <div className="group border border-line bg-panel/70 transition-all duration-300 hover:-translate-y-1.5 hover:border-lime/40" data-mag>
                  <div className="relative overflow-hidden">
                    <img src={t.img} alt={t.name} loading="lazy" className="aspect-[3/4] w-full object-cover object-top grayscale-[35%] transition-all duration-700 group-hover:scale-[1.05] group-hover:grayscale-0" />
                    <div className="absolute inset-0 bg-gradient-to-t from-panel via-transparent to-transparent" />
                    <span className="absolute right-3 top-3 border border-gold/50 bg-pit/70 px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-gold backdrop-blur">
                      ★ {t.rating}
                    </span>
                  </div>
                  <div className="p-5">
                    <p className="font-display text-lg font-bold uppercase leading-tight text-ink">{t.name}</p>
                    <p className="mt-1 font-mono text-[10px] uppercase tracking-widest text-lime">{t.role}</p>
                    <p className="mt-2 text-xs leading-relaxed text-mute">{t.spec} · {t.years} yrs</p>
                  </div>
                </div>
              </Reveal>)}
          </div>
          <Reveal delay={200}>
            <div className="mt-14 flex flex-col items-start justify-between gap-6 border border-line bg-panel/60 p-8 md:flex-row md:items-center">
              <p className="font-display text-3xl font-bold uppercase text-ink">
                Want one of them on <span className="text-lime">your car?</span>
              </p>
              <Link href="/assistant?intent=book" className="btn-primary shrink-0">Book with Jane <Icon name="arrow" size={16} /></Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>;
}
export {
  AboutPage as default
};
