"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { MODELS, SERVICES, WORKSHOP } from "@/lib/services";
import {
  CompareSlider,
  Counter,
  Icon,
  Marquee,
  Reveal,
  Scramble,
  SectionHead
} from "@/components/fx";
function HeroMedia() {
  return <div className="absolute inset-0 overflow-hidden bg-bg">
      <div className="absolute left-1/2 top-1/2 h-[120vh] w-[120vw] min-h-[177.78vw] min-w-full -translate-x-1/2 -translate-y-1/2 opacity-70">
        <iframe
    className="h-full w-full"
    src="https://www.youtube.com/embed/5RbtlslVGJA?autoplay=1&mute=1&controls=0&loop=1&playlist=5RbtlslVGJA&playsinline=1&rel=0&modestbranding=1&iv_load_policy=3&disablekb=1&fs=0"
    title="Land Rover — cinematic background"
    allow="autoplay; encrypted-media"
    tabIndex={-1}
    aria-hidden
  />
      </div>
      <div className="absolute inset-0 bg-gradient-to-r from-bg via-bg/72 to-bg/25" />
      <div className="absolute inset-0 bg-gradient-to-t from-bg via-transparent to-bg/70" />
      <div className="gridlines absolute inset-0 opacity-40 [mask-image:radial-gradient(70%_60%_at_30%_45%,black,transparent)]" />
    </div>;
}
function Hud() {
  const [telemetry, setTelemetry] = useState({
    capacity: 8,
    baysFree: 8,
    occupied: 0,
    queueToday: 0,
    activeJobs: 0,
    carsInBay: 0,
    vehiclesOnFile: 0,
    pathfinderConnected: true,
    aiAccuracy: 99.2
  });
  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch(`/api/workshop/telemetry?t=${Date.now()}`, { cache: "no-store" });
        if (res.ok) setTelemetry(await res.json());
      } catch {
      }
    };
    const onVisibility = () => {
      if (!document.hidden) load();
    };
    const onStorage = (event) => {
      if (event.key === "baydoun-vehicles-updated-at") load();
    };
    const channel = "BroadcastChannel" in window ? new BroadcastChannel("baydoun-workshop-telemetry") : null;
    if (channel) channel.onmessage = (event) => {
      if (event.data === "vehicles-updated") load();
    };
    load();
    const id = setInterval(load, 5e3);
    window.addEventListener("focus", load);
    window.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("storage", onStorage);
    window.addEventListener("baydoun-vehicles-updated", load);
    return () => {
      clearInterval(id);
      channel?.close();
      window.removeEventListener("focus", load);
      window.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("baydoun-vehicles-updated", load);
    };
  }, []);
  return <div className="panel relative hidden w-[340px] overflow-hidden p-6 xl:block">
      <div
    aria-hidden
    className="pointer-events-none absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-lime/8 to-transparent"
    style={{ animation: "scanline 5s linear infinite" }}
  />
      <p className="mono-label mb-5 flex items-center justify-between">
        <span>Workshop telemetry</span>
        <span className="anim-blink text-lime">▌</span>
      </p>
      <div className="space-y-4 font-mono text-[11px] uppercase tracking-widest text-mute">
        <div>
          <div className="mb-1.5 flex justify-between">
            <span>Bays free</span>
            <span className="text-lime">{telemetry.baysFree} / {telemetry.capacity}</span>
          </div>
          <div className="flex gap-1">
            {Array.from({ length: telemetry.capacity }).map((_, i) => <span
    key={i}
    className={`h-1.5 flex-1 transition-colors duration-500 ${i < telemetry.baysFree ? "bg-lime/80" : "bg-raise"}`}
  />)}
          </div>
        </div>
        <div className="flex justify-between border-t border-line pt-3">
          <span>Queue today</span>
          <span className="text-ink">{telemetry.queueToday} vehicles</span>
        </div>
        <div className="flex justify-between">
          <span>Cars in bay</span>
          <span className="text-lime">{telemetry.carsInBay}</span>
        </div>
        <div className="flex justify-between">
          <span>Pathfinder link</span>
          <span className="text-racing2">{telemetry.pathfinderConnected ? "Connected" : "Offline"}</span>
        </div>
        <div className="flex justify-between">
          <span>AI diag. accuracy</span>
          <span className="text-ink">{telemetry.aiAccuracy}%</span>
        </div>
      </div>
      <div className="mt-5 flex items-center justify-center border-t border-line pt-5">
        <svg width="150" height="86" viewBox="0 0 150 86" aria-hidden>
          <path d="M15 78 A60 60 0 0 1 135 78" fill="none" stroke="rgba(231,238,234,0.12)" strokeWidth="6" />
          <path d="M15 78 A60 60 0 0 1 135 78" fill="none" stroke="url(#gg)" strokeWidth="6" strokeDasharray="150" strokeDashoffset="30" strokeLinecap="round" />
          <defs>
            <linearGradient id="gg" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#1e6e52" />
              <stop offset="100%" stopColor="#c9f158" />
            </linearGradient>
          </defs>
          <g style={{ transformOrigin: "75px 78px", animation: "needleSweep 3.4s cubic-bezier(.3,1.4,.4,1) infinite alternate" }}>
            <line x1="75" y1="78" x2="75" y2="26" stroke="#c9f158" strokeWidth="2" />
          </g>
          <circle cx="75" cy="78" r="4" fill="#c9f158" />
        </svg>
      </div>
      <p className="mt-4 text-center font-mono text-[10px] uppercase tracking-[0.22em] text-dim">
        Live from the workshop floor
      </p>
    </div>;
}
const QUOTES = [
  {
    text: "The dealership quoted a full loom replacement. Dany found one corroded connector in 40 minutes and saved me $3,000.",
    name: "Nabil G.",
    car: "Defender 110"
  },
  {
    text: "Jane the AI assistant booked my air-suspension repair at 2 a.m. The car was fixed the same day \u2014 with a courtesy Defender waiting.",
    name: "Sarah M.",
    car: "Range Rover Velar"
  },
  {
    text: "They rebuilt my 1996 Defender 90 like it left Solihull yesterday. Every bolt torqued, every panel aligned.",
    name: "Karim A.",
    car: "Classic Defender 90"
  }
];
function QuoteRotator() {
  const [i, setI] = useState(0);
  const hover = useRef(false);
  useEffect(() => {
    const id = setInterval(() => {
      if (!hover.current) setI((v) => (v + 1) % QUOTES.length);
    }, 5200);
    return () => clearInterval(id);
  }, []);
  const q = QUOTES[i];
  return <div
    onMouseEnter={() => hover.current = true}
    onMouseLeave={() => hover.current = false}
    className="relative"
  >
      <div key={i} className="anim-rise">
        <p className="font-display text-2xl font-medium leading-snug text-ink md:text-[28px]">
          “{q.text}”
        </p>
        <p className="mt-5 font-mono text-[11px] uppercase tracking-[0.2em] text-mute">
          <span className="text-lime">{q.name}</span> · {q.car}
        </p>
      </div>
      <div className="mt-7 flex gap-2">
        {QUOTES.map((_, idx) => <button
    key={idx}
    onClick={() => setI(idx)}
    aria-label={`Quote ${idx + 1}`}
    className={`h-1 transition-all duration-500 ${idx === i ? "w-10 bg-lime" : "w-5 bg-raise"}`}
  />)}
      </div>
    </div>;
}
function HomeContactDisplay() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "General enquiry", message: "" });
  const [err, setErr] = useState(null);
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const d = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) return setErr(d.error || "Could not send \u2014 try WhatsApp instead.");
    setSent(true);
    setForm({ name: "", email: "", phone: "", subject: "General enquiry", message: "" });
  };
  return <Reveal delay={220}>
      <div className="mt-12 grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="space-y-8">
          <div className="border border-line bg-panel/60 p-8 md:p-10">
            <p className="mono-label mb-8 tracking-[0.32em]">Direct lines</p>
            <ul className="space-y-6">
              {[
    { icon: "pin", k: "The atelier", v: WORKSHOP.address, href: WORKSHOP.mapUrl, accent: false, external: true },
    { icon: "phone", k: "Phone", v: WORKSHOP.phone, href: `tel:${WORKSHOP.phone.replace(/\s/g, "")}`, accent: false, external: false },
    { icon: "whatsapp", k: "WhatsApp", v: WORKSHOP.whatsapp, href: WORKSHOP.whatsappLink, accent: true, external: true },
    { icon: "doc", k: "Email", v: WORKSHOP.email, href: `mailto:${WORKSHOP.email}`, accent: false, external: false }
  ].map((row) => <li key={row.k}>
                  <a
    href={row.href}
    target={row.external ? "_blank" : void 0}
    rel={row.external ? "noreferrer" : void 0}
    className="group flex items-center gap-5"
  >
                    <span className={`grid h-14 w-14 shrink-0 place-items-center border transition-all duration-300 ${row.accent ? "border-[#25d366]/60 text-[#25d366] group-hover:bg-[#25d366]/10" : "border-line2 text-lime group-hover:border-lime/70 group-hover:bg-lime/10"}`}>
                      <Icon name={row.icon} size={20} />
                    </span>
                    <span>
                      <span className="mono-label block !text-[10px]">{row.k}</span>
                      <span className={`mt-1 block text-base font-medium leading-snug md:text-lg ${row.accent ? "text-[#25d366]" : "text-ink group-hover:text-lime"}`}>
                        {row.v}
                      </span>
                    </span>
                  </a>
                </li>)}
            </ul>
          </div>

          <div className="border border-line bg-panel/60 p-8 md:p-10">
            <p className="mono-label mb-6 tracking-[0.32em]">Opening hours</p>
            <div className="space-y-3 text-sm md:text-base">
              {WORKSHOP.hoursDetail.map(([day, hours]) => <p key={day} className="flex items-center justify-between gap-6 text-mute">
                  <span>{day}</span>
                  <span className="font-mono text-xs uppercase tracking-[0.18em] text-ink">{hours}</span>
                </p>)}
            </div>
            <p className="mt-7 border-t border-line pt-5 text-sm leading-relaxed text-dim">
              Recovery line 07:00–22:00, seven days. For bookings, Jane never sleeps.
            </p>
          </div>

          <div className="overflow-hidden border border-line bg-panel/50">
            <iframe
    title="Baydoun workshop location map"
    src={WORKSHOP.mapEmbed}
    className="h-64 w-full grayscale invert-[0.92] contrast-[0.9] hue-rotate-[120deg]"
    loading="lazy"
  />
          </div>
        </div>

        <form onSubmit={submit} className="panel relative overflow-hidden p-8 md:p-10">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-racing via-lime to-racing" />
          <p className="font-display text-4xl font-bold uppercase text-ink md:text-5xl">Send a message</p>
          <p className="mt-3 text-base text-mute">
            Fleet enquiries, insurance repairs, careers — all read by a human.
          </p>
          {sent ? <div className="mt-8 border border-lime/40 bg-lime/10 p-6 text-center">
              <p className="font-display text-2xl font-bold uppercase text-lime">Message received ✓</p>
              <p className="mt-2 text-sm text-mute">A service advisor will reply within the hour during opening times.</p>
            </div> : <div className="mt-10 grid gap-6 sm:grid-cols-2">
              <label className="block">
                <span className="mono-label">Name</span>
                <input
    required
    value={form.name}
    onChange={(e) => setForm({ ...form, name: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-4 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="Your name"
  />
              </label>
              <label className="block">
                <span className="mono-label">Email</span>
                <input
    type="email"
    value={form.email}
    onChange={(e) => setForm({ ...form, email: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-4 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="you@example.com"
  />
              </label>
              <label className="block">
                <span className="mono-label">Phone</span>
                <input
    value={form.phone}
    onChange={(e) => setForm({ ...form, phone: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-4 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="+961…"
  />
              </label>
              <label className="block">
                <span className="mono-label">Subject</span>
                <select
    value={form.subject}
    onChange={(e) => setForm({ ...form, subject: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-4 text-ink focus:border-lime/60 focus:outline-none"
  >
                  {["General enquiry", "Fleet & corporate", "Insurance repair", "Careers", "Press"].map((s) => <option key={s}>{s}</option>)}
                </select>
              </label>
              <label className="block sm:col-span-2">
                <span className="mono-label">Message</span>
                <textarea
    required
    rows={6}
    value={form.message}
    onChange={(e) => setForm({ ...form, message: e.target.value })}
    className="mt-2 w-full resize-none border border-line2 bg-pit px-4 py-4 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="Tell us about the vehicle, the issue, or the project…"
  />
              </label>
              {err && <p className="border border-alert/40 bg-alert/10 px-3 py-2.5 text-sm text-alert sm:col-span-2">{err}</p>}
              <div className="sm:col-span-2">
                <button type="submit" disabled={busy} className="btn-primary w-full justify-center disabled:opacity-50">
                  {busy ? "Sending\u2026" : "Send to the atelier"}
                </button>
              </div>
            </div>}
        </form>
      </div>
    </Reveal>;
}
function HomePage() {
  return <>
      {
    /* ================= HERO ================= */
  }
      <section className="relative flex min-h-[94vh] items-center overflow-hidden">
        <HeroMedia />
        <div className="relative z-[2] mx-auto flex w-full max-w-[1400px] items-center justify-between gap-16 px-4 pb-24 pt-16 md:px-8">
          <div className="max-w-3xl">
            <p className="mono-label mb-7 flex items-center gap-3 text-mute">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime pulse-dot" />
              Est. 1996 · Independent Land Rover Specialists
            </p>
            <h1 className="font-display text-[15vw] font-bold uppercase leading-[0.86] tracking-tight text-ink sm:text-7xl lg:text-[92px]">
              <Scramble text="Precision" className="block" />
              <Scramble text="engineering," delay={250} className="block text-transparent [-webkit-text-stroke:1.5px_rgba(233,239,236,0.85)]" />
              <Scramble text="perfected." delay={500} className="block text-lime" />
            </h1>
            <Reveal delay={650}>
              <p className="mt-8 max-w-xl text-base leading-relaxed text-mute md:text-lg">
                Where engineering meets perfection. Master technicians, factory tooling and an AI
                service assistant that books, diagnoses and tracks your Land Rover — around the
                clock.
              </p>
            </Reveal>
            <Reveal delay={800}>
              <div className="mt-10 flex flex-wrap items-center gap-4">
                <Link href="/assistant?intent=book" className="btn-primary">
                  <Icon name="chat" size={18} />
                  Book with the AI
                </Link>
                <Link href="/services" className="btn-ghost">
                  Explore services
                  <Icon name="arrow" size={16} />
                </Link>
              </div>
            </Reveal>
            <Reveal delay={950}>
              <p className="mt-10 flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.2em] text-dim">
                <span className="inline-flex gap-1 text-gold">
                  {Array.from({ length: 5 }).map((_, idx) => <Icon key={idx} name="star" size={11} className="fill-gold stroke-none" />)}
                </span>
                4.9 from 1,180 owner reviews
              </p>
            </Reveal>
          </div>
          <Reveal delay={500} className="hidden xl:block">
            <Hud />
          </Reveal>
        </div>
        <div className="absolute bottom-7 left-1/2 z-[2] -translate-x-1/2">
          <div className="flex h-10 w-6 items-start justify-center border border-line2 p-1.5">
            <span className="h-2 w-0.5 bg-lime" style={{ animation: "rise 1.6s ease-in-out infinite" }} />
          </div>
        </div>
      </section>

      {
    /* ================= MODEL MARQUEE ================= */
  }
      <section className="border-y border-line bg-pit/70 py-5">
        <Marquee speed={40}>
          {MODELS.map((m) => <span key={m} className="flex items-center">
              <span className="px-8 font-display text-xl font-semibold uppercase tracking-[0.14em] text-mute transition-colors hover:text-lime">
                {m}
              </span>
              <span className="h-1.5 w-1.5 rotate-45 bg-racing" aria-hidden />
            </span>)}
        </Marquee>
      </section>

      {
    /* ================= STATS ================= */
  }
      <section className="relative border-b border-line">
        <div className="glow-racing pointer-events-none absolute -top-24 right-0 h-[380px] w-[560px]" aria-hidden />
        <div className="mx-auto grid max-w-[1400px] grid-cols-2 divide-x divide-line border-x border-line md:grid-cols-5">
          {[
    { to: 500, suffix: "+", label: "Vehicles repaired" },
    { to: 98, suffix: ".6%", label: "Owner satisfaction" },
    { to: 28, suffix: " yrs", label: "Land Rover only" },
    { to: 14, suffix: "", label: "Certified technicians" },
    { to: 99, suffix: ".2%", label: "AI diagnostics accuracy" }
  ].map((s, i) => <div key={s.label} className={`px-6 py-10 ${i > 1 ? "border-t border-line md:border-t-0" : ""}`}>
              <p className="font-display text-4xl font-bold text-ink md:text-5xl">
                <Counter to={s.to} suffix={s.suffix} />
              </p>
              <p className="mono-label mt-3 !text-mute">{s.label}</p>
            </div>)}
        </div>
      </section>

      {
    /* ================= INTRO ================= */
  }
      <section className="mx-auto max-w-[1400px] px-4 py-24 md:px-8 md:py-32">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <div>
            <SectionHead
    kicker="The atelier"
    title={<>
                  Where engineering
                  <br />
                  meets <span className="text-lime">perfection</span>
                </>}
  />
            <Reveal delay={120}>
              <p className="max-w-xl text-base leading-relaxed text-mute">
                We service nothing but Land Rovers — and we've done nothing else for 28 years.
                Every bay runs JLR Pathfinder diagnostics, every torque value is logged, and every
                repair is signed off by a master technician who has spent a career on Solihull's
                finest.
              </p>
            </Reveal>
            <div className="mt-10 space-y-5">
              {[
    { icon: "shield", t: "Genuine JLR parts only", d: "Serial-traced, recorded in your digital service book." },
    { icon: "chip", t: "Factory tooling & software", d: "Pathfinder, SDD and approved calibration files \u2014 never hacks." },
    { icon: "key", t: "Concierge pickup + courtesy Defender", d: "We collect your Land Rover, leave you mobile, and return it detailed." }
  ].map((f, i) => <Reveal key={f.t} delay={i * 110}>
                  <div className="group flex gap-5 border border-line bg-panel/50 p-5 transition-all duration-300 hover:-translate-y-1 hover:border-lime/40">
                    <span className="grid h-11 w-11 shrink-0 place-items-center border border-line2 text-lime transition-colors duration-300 group-hover:border-lime/60 group-hover:bg-lime/10">
                      <Icon name={f.icon} size={20} />
                    </span>
                    <div>
                      <p className="font-display text-lg font-semibold uppercase tracking-wide text-ink">{f.t}</p>
                      <p className="mt-1 text-sm text-mute">{f.d}</p>
                    </div>
                  </div>
                </Reveal>)}
            </div>
          </div>
          <Reveal delay={200}>
            <div className="group relative overflow-hidden border border-line" data-mag>
              <img
    src="/images/workshop.jpg"
    alt="Inside the Baydoun Land Rover atelier"
    className="anim-kenburns block aspect-[4/5] w-full object-cover"
  />
              <div className="absolute inset-0 bg-gradient-to-t from-pit via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 flex items-end justify-between p-6">
                <div>
                  <p className="mono-label !text-mute">Bay 03 — Air suspension</p>
                  <p className="mt-1 font-display text-2xl font-bold uppercase text-ink">Atelier district, Beirut</p>
                </div>
                <Link href="/about" aria-label="About the atelier" className="grid h-12 w-12 place-items-center border border-line2 bg-pit/60 text-lime backdrop-blur transition-all duration-300 hover:bg-lime hover:text-pit">
                  <Icon name="arrow" size={18} />
                </Link>
              </div>
              <span className="absolute right-5 top-5 border border-lime/40 bg-pit/70 px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-lime backdrop-blur">
                ● Live bay cam
              </span>
            </div>
          </Reveal>
        </div>
      </section>

      {
    /* ================= SERVICES ================= */
  }
      <section className="relative border-t border-line bg-pit/50 py-24 md:py-32">
        <div className="mx-auto max-w-[1400px] px-4 md:px-8">
          <SectionHead
    kicker="Capabilities — 13 disciplines"
    title={<>
                Every system.
                <br />
                <span className="text-outline">One standard.</span>
              </>}
    right={<Link href="/services" className="btn-ghost">
                All services <Icon name="arrow" size={16} />
              </Link>}
  />
          <div className="grid gap-px border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
            {SERVICES.map((s, i) => {
    const big = i < 2;
    return <Link
      key={s.slug}
      href={`/services/${s.slug}`}
      className={`group relative overflow-hidden bg-panel transition-colors duration-500 hover:bg-panel2 ${big ? "sm:col-span-2" : ""}`}
      data-mag
    >
                  <div className={`relative overflow-hidden ${big ? "aspect-[16/7]" : "aspect-[16/10]"}`}>
                    <img
      src={s.image}
      alt={s.alt}
      loading="lazy"
      className="absolute inset-0 h-full w-full object-cover opacity-70 transition-all duration-700 group-hover:scale-[1.06] group-hover:opacity-90"
    />
                    <div className="absolute inset-0 bg-gradient-to-t from-panel via-panel/30 to-transparent" />
                    <span className="absolute left-4 top-4 font-mono text-[10px] tracking-[0.2em] text-lime">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="absolute right-4 top-4 grid h-9 w-9 place-items-center border border-line2 bg-pit/60 text-mute opacity-0 backdrop-blur transition-all duration-500 group-hover:opacity-100 group-hover:text-lime">
                      <Icon name="arrow" size={15} />
                    </span>
                  </div>
                  <div className="relative -mt-10 px-5 pb-5">
                    <p className="mono-label mb-1.5">{s.tag}</p>
                    <h3 className={`font-display font-bold uppercase leading-tight text-ink ${big ? "text-3xl" : "text-xl"}`}>
                      {s.name}
                    </h3>
                    <p className="mt-2 line-clamp-2 text-sm text-mute">{s.summary}</p>
                    <p className="mt-3 font-mono text-[11px] uppercase tracking-widest text-gold">
                      JLR-only master bay
                    </p>
                  </div>
                </Link>;
  })}
            {
    /* filler tile with CTA */
  }
            <Link
    href="/assistant"
    className="group relative flex flex-col justify-between overflow-hidden bg-racing/20 p-6 transition-colors duration-500 hover:bg-racing/30"
    data-mag
  >
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-racing2">Not sure what it needs?</p>
              <div>
                <p className="font-display text-2xl font-bold uppercase leading-tight text-ink">
                  Ask the AI
                  <br />
                  mechanic
                </p>
                <span className="mt-4 inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-widest text-lime">
                  Diagnose free <Icon name="arrow" size={14} className="transition-transform duration-300 group-hover:translate-x-1.5" />
                </span>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {
    /* ================= AI ASSISTANT PROMO ================= */
  }
      <section className="relative overflow-hidden border-t border-line py-24 md:py-32">
        <div className="glow-lime pointer-events-none absolute left-0 top-1/3 h-[420px] w-[620px]" aria-hidden />
        <div className="mx-auto grid max-w-[1400px] items-center gap-16 px-4 md:px-8 lg:grid-cols-2">
          <div>
            <SectionHead
    kicker="Jane — 24/7 AI service assistant"
    title={<>
                  Your mechanic
                  <br />
                  never <span className="text-lime">sleeps</span>
                </>}
  />
            <Reveal delay={140}>
              <p className="max-w-xl text-base leading-relaxed text-mute">
                Jane books services in plain language, checks live bay availability, diagnoses
                symptoms against 25 years of Land Rover failure data, tracks your repair and
                hands over to a human advisor the moment you ask.
              </p>
            </Reveal>
            <div className="mt-10 grid gap-4 sm:grid-cols-2">
              {[
    ["chat", "Natural-language booking", "\u201CBook air suspension for my Defender, Thursday morning\u201D \u2014 done."],
    ["gauge", "Instant symptom triage", "Urgency ranking, cost bands and safety advice in seconds."],
    ["calendar", "Live availability", "Real bay schedule \u2014 Jane only offers slots that are actually free."],
    ["shield", "VIN decode & recalls", "Paste a VIN for build data and an open-recall check."]
  ].map(([icon, t, d], i) => <Reveal key={t} delay={i * 100}>
                  <div className="h-full border border-line bg-panel/60 p-5 transition-all duration-300 hover:-translate-y-1 hover:border-lime/40">
                    <Icon name={icon} size={22} className="text-lime" />
                    <p className="mt-3 font-display text-base font-semibold uppercase tracking-wide text-ink">{t}</p>
                    <p className="mt-1.5 text-sm leading-relaxed text-mute">{d}</p>
                  </div>
                </Reveal>)}
            </div>
            <Reveal delay={300}>
              <Link href="/assistant?intent=book" className="btn-primary mt-10">
                <Icon name="chat" size={18} /> Chat with Jane
              </Link>
            </Reveal>
          </div>
          {
    /* animated chat mock */
  }
          <Reveal delay={200}>
            <div className="panel anim-floaty relative overflow-hidden p-6">
              <div className="mb-5 flex items-center gap-3 border-b border-line pb-4">
                <span className="relative grid h-10 w-10 place-items-center border border-lime/50 bg-lime/10 font-display font-bold text-lime">
                  J
                  <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-panel bg-lime pulse-dot" />
                </span>
                <div>
                  <p className="font-display text-sm font-bold uppercase tracking-wider text-ink">Jane · AI Assistant</p>
                  <p className="font-mono text-[10px] uppercase tracking-widest text-racing2">Online — replies in ~2s</p>
                </div>
                <span className="ml-auto border border-line2 px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-mute">GPT · RAG</span>
              </div>
              <div className="space-y-4">
                <div className="anim-rise max-w-[85%] border border-line bg-panel2 p-3.5 text-sm leading-relaxed text-ink" style={{ animationDelay: "0.2s" }}>
                  My Defender is sagging on the front-left corner overnight 🙁
                </div>
                <div className="anim-rise ml-auto max-w-[85%] border border-lime/25 bg-lime/5 p-3.5 text-sm leading-relaxed text-ink" style={{ animationDelay: "0.7s" }}>
                  Classic EAS symptom — likely a tired air spring or a compressor compensating all night.
                  <span className="mt-2 block font-mono text-[10px] uppercase tracking-widest text-lime">Urgency: book within 48h · est. $390–$940</span>
                </div>
                <div className="anim-rise max-w-[85%] border border-line bg-panel2 p-3.5 text-sm leading-relaxed text-ink" style={{ animationDelay: "1.2s" }}>
                  Book it for Thursday morning?
                </div>
                <div className="anim-rise ml-auto max-w-[85%] border border-lime/25 bg-lime/5 p-3.5 text-sm leading-relaxed text-ink" style={{ animationDelay: "1.7s" }}>
                  Done ✅ <span className="font-mono text-lime">BLR-4821</span> — Thursday 09:00 with Karim. Bay 3, air-suspension rig.
                  <span className="mt-2 flex flex-wrap gap-2">
                    <span className="chip">⏱ 09:00</span>
                    <span className="chip">📍 Bay 03</span>
                    <span className="chip">👨‍🔧 Karim</span>
                  </span>
                </div>
              </div>
              <div className="mt-5 flex gap-2">
                {["Book a service", "Diagnose a noise", "Where are you?"].map((c) => <span key={c} className="chip">{c}</span>)}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {
    /* ================= RANGE ROVER ENGINE TRANSFORMATION ================= */
  }
      <section className="relative overflow-hidden border-t border-line bg-pit/50 py-24 md:py-32">
        <div className="glow-racing pointer-events-none absolute -right-32 top-1/4 h-[420px] w-[640px]" aria-hidden />
        <div className="mx-auto grid max-w-[1400px] items-center gap-14 px-4 md:px-8 lg:grid-cols-[1.2fr_1fr]">
          <Reveal>
            <CompareSlider before="/images/range-engine-before.jpg" after="/images/range-engine-after.jpg" />
          </Reveal>
          <div>
            <SectionHead
    kicker="Range Rover engine bay"
    title={<>
                  From silent shell
                  <br />
                  to <span className="text-lime">living power</span>
                </>}
  />
            <Reveal delay={140}>
              <p className="max-w-lg text-base leading-relaxed text-mute">
                Slide between a Range Rover with the powertrain removed and the same bay rebuilt,
                installed, coded and calibrated. Every connector, mount, fluid path and control
                module is verified before the first ignition cycle.
              </p>
            </Reveal>
            <Reveal delay={210}>
              <div className="mt-7 grid gap-3 sm:grid-cols-2">
                <div className="border border-line bg-panel/60 p-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-dim">Before</p>
                  <p className="mt-1 font-display text-lg font-bold uppercase text-ink">Engine removed</p>
                </div>
                <div className="border border-lime/30 bg-lime/5 p-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-lime">After</p>
                  <p className="mt-1 font-display text-lg font-bold uppercase text-ink">Installed + calibrated</p>
                </div>
              </div>
            </Reveal>
            <Reveal delay={280}>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link href="/services/engine-diagnostics" className="btn-ghost">
                  Explore engine care <Icon name="arrow" size={16} />
                </Link>
                <Link href="/assistant?service=engine-diagnostics" className="btn-primary">
                  Ask Jane about your engine
                </Link>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {
    /* ================= REVIEWS + VISIT ================= */
  }
      <section className="mx-auto max-w-[1400px] px-4 py-24 md:px-8 md:py-32">
        <div className="grid gap-14 lg:grid-cols-2">
          <div className="border border-line bg-panel/60 p-8 md:p-10">
            <p className="mono-label mb-6 flex items-center gap-3">
              <span className="inline-block h-px w-10 bg-lime/70" /> Owner voices
            </p>
            <QuoteRotator />
            <div className="mt-8 flex items-center justify-between border-t border-line pt-6">
              <p className="font-mono text-[11px] uppercase tracking-widest text-mute">
                4.9 ★ · 1,180 verified reviews
              </p>
              <Link href="/reviews" className="font-display text-sm font-semibold uppercase tracking-wider text-lime transition-colors hover:text-ink">
                Read all →
              </Link>
            </div>
          </div>
          <div className="gridlines relative overflow-hidden border border-line bg-panel/60 p-8 md:p-10">
            <div className="glow-racing pointer-events-none absolute -right-20 -top-20 h-72 w-72" aria-hidden />
            <p className="mono-label mb-6 flex items-center gap-3">
              <span className="inline-block h-px w-10 bg-lime/70" /> Visit the atelier
            </p>
            <h3 className="font-display text-4xl font-bold uppercase leading-[0.95] text-ink md:text-5xl">
              Eight bays.
              <br />
              Zero <span className="text-outline">guesswork.</span>
            </h3>
            <div className="mt-8 space-y-3 font-mono text-[12px] uppercase tracking-widest text-mute">
              <p className="flex items-center gap-3"><Icon name="pin" size={15} className="text-lime" /> {WORKSHOP.address}</p>
              <p className="flex items-center gap-3"><Icon name="calendar" size={15} className="text-lime" /> {WORKSHOP.hours}</p>
              <p className="flex items-center gap-3"><Icon name="phone" size={15} className="text-lime" /> {WORKSHOP.phone}</p>
            </div>
            <div className="mt-9 flex flex-wrap gap-4">
              <Link href="/assistant?intent=book" className="btn-primary">Reserve a bay</Link>
              <Link href="/contact" className="btn-ghost">Plan your visit</Link>
            </div>
          </div>
        </div>
        <HomeContactDisplay />
      </section>
    </>;
}
export {
  HomePage as default
};
