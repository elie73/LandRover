"use client";
import { useState } from "react";
import { CompareSlider, Icon, Reveal, Scramble } from "@/components/fx";
const SHOTS = [
  { src: "/images/hero-poster.jpg", alt: "Defender under studio light", cat: "Vehicles" },
  { src: "https://images.pexels.com/photos/4489703/pexels-photo-4489703.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", alt: "Night shift on the lift", cat: "Workshop" },
  { src: "https://images.pexels.com/photos/35474226/pexels-photo-35474226.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", alt: "Defender grille in first snow", cat: "Vehicles" },
  { src: "https://images.pexels.com/photos/4489702/pexels-photo-4489702.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", alt: "Fabrication sparks", cat: "Workshop", tall: true },
  { src: "https://images.pexels.com/photos/32494406/pexels-photo-32494406.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", alt: "Black Defender at twilight", cat: "Vehicles" },
  { src: "/images/workshop.jpg", alt: "Atelier floor, bay 03", cat: "Workshop", tall: true },
  { src: "https://images.pexels.com/photos/19721324/pexels-photo-19721324.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", alt: "Defender in motion, golden hour", cat: "Vehicles" },
  { src: "https://images.pexels.com/photos/7541344/pexels-photo-7541344.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", alt: "Tools of the trade", cat: "Workshop" },
  { src: "https://images.pexels.com/photos/8986105/pexels-photo-8986105.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", alt: "Underbody inspection", cat: "Workshop" },
  { src: "https://images.pexels.com/photos/19721317/pexels-photo-19721317.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", alt: "Sunset convoy", cat: "Vehicles" },
  { src: "https://images.pexels.com/photos/4489721/pexels-photo-4489721.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", alt: "Late-night diagnostics", cat: "Workshop" }
];
const CATS = ["All", "Vehicles", "Workshop", "Restoration"];
function GalleryPage() {
  const [cat, setCat] = useState("All");
  const [lightbox, setLightbox] = useState(null);
  const shots = SHOTS.filter((s) => cat === "All" || s.cat === cat);
  return <>
      <section className="relative overflow-hidden border-b border-line">
        <div className="carbon absolute inset-0 opacity-50" aria-hidden />
        <div className="relative mx-auto max-w-[1400px] px-4 pb-16 pt-20 md:px-8">
          <p className="mono-label mb-6 flex items-center gap-3">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime pulse-dot" /> The floor, the builds, the light
          </p>
          <h1 className="font-display text-6xl font-bold uppercase leading-[0.88] text-ink md:text-8xl">
            <Scramble text="Gallery" /> <span className="text-outline"><Scramble text="of obsession" delay={200} /></span>
          </h1>
          <div className="mt-8 flex flex-wrap gap-2.5">
            {CATS.map((c) => <button
    key={c}
    onClick={() => setCat(c)}
    className={`px-4 py-2 font-mono text-[11px] uppercase tracking-[0.18em] transition-all duration-300 ${cat === c ? "bg-lime text-pit" : "border border-line2 text-mute hover:border-lime/50 hover:text-ink"}`}
  >
                {c}
              </button>)}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-4 py-14 md:px-8">
        {cat === "Restoration" ? <div className="grid items-center gap-12 lg:grid-cols-[1.3fr_1fr]">
            <Reveal>
              <CompareSlider before="/images/restore-before.jpg" after="/images/restore-after.jpg" />
            </Reveal>
            <Reveal delay={150}>
              <p className="mono-label mb-4">Case 114 · Classic 90</p>
              <h2 className="font-display text-4xl font-bold uppercase leading-[0.95] text-ink">
                From barn-find to <span className="text-lime">concourse green</span>
              </h2>
              <p className="mt-5 max-w-md text-base leading-relaxed text-mute">
                Fourteen months, 1,900 photographs, every nut catalogued. Drag the slider — then
                imagine your own project in the frame.
              </p>
              <a href="/contact" className="btn-ghost mt-7">Commission a restoration</a>
            </Reveal>
          </div> : <div className="columns-1 gap-5 sm:columns-2 lg:columns-3">
            {shots.map((s, i) => <Reveal key={s.src} delay={Math.min(i * 60, 300)} className="mb-5 break-inside-avoid">
                <button onClick={() => setLightbox(s)} className="group relative block w-full overflow-hidden border border-line text-left" data-mag>
                  <img
    src={s.src}
    alt={s.alt}
    loading="lazy"
    className={`w-full object-cover transition-transform duration-700 group-hover:scale-[1.05] ${s.tall ? "aspect-[3/4]" : "aspect-[4/3]"}`}
  />
                  <div className="absolute inset-0 bg-gradient-to-t from-pit/90 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                  <div className="absolute bottom-0 left-0 right-0 flex translate-y-3 items-center justify-between p-4 opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                    <p className="font-display text-sm font-semibold uppercase tracking-wide text-ink">{s.alt}</p>
                    <Icon name="arrow" size={16} className="text-lime" />
                  </div>
                  <span className="absolute left-3 top-3 border border-line2 bg-pit/60 px-2 py-1 font-mono text-[9px] uppercase tracking-widest text-mute backdrop-blur">
                    {s.cat}
                  </span>
                </button>
              </Reveal>)}
          </div>}
      </section>

      {lightbox && <div className="fixed inset-0 z-[130] grid place-items-center bg-pit/90 p-4 backdrop-blur-md" role="dialog" aria-modal="true" onClick={() => setLightbox(null)}>
          <figure className="anim-rise max-h-[88vh] max-w-5xl" onClick={(e) => e.stopPropagation()}>
            <img src={lightbox.src} alt={lightbox.alt} className="max-h-[80vh] w-auto border border-line2 object-contain" />
            <figcaption className="mt-4 flex items-center justify-between gap-4">
              <span className="font-mono text-[11px] uppercase tracking-widest text-mute">{lightbox.alt} · {lightbox.cat}</span>
              <button onClick={() => setLightbox(null)} className="btn-ghost !px-4 !py-2 text-xs">Close ✕</button>
            </figcaption>
          </figure>
        </div>}
    </>;
}
export {
  GalleryPage as default
};
