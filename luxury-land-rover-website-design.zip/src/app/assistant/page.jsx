"use client";
import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { WORKSHOP } from "@/lib/services";
import { CLOSING, WELCOME_QUICK, WELCOME_REPLIES } from "@/lib/aiText";
import { Icon, Reveal, TypingDots } from "@/components/fx";
import { labelDate } from "@/lib/utils";
const cleanForSpeech = (text) => text.replace(/\*\*([^*]+)\*\*/g, "$1").replace(/[✅🙏👋🛠⚠️🚗🔧📍📅❓💬📞📝👨‍🔧🗓]/g, "").replace(/\s+/g, " ").trim();
const renderText = (text) => text.split("\n").map((line, i) => <span key={i}>
      {i > 0 && <br />}
      {line.split(/(\*\*[^*]+\*\*)/g).map(
  (part, j) => part.startsWith("**") && part.endsWith("**") ? <strong key={j} className="font-semibold text-ink">
            {part.slice(2, -2)}
          </strong> : <span key={j}>{part}</span>
)}
    </span>);
function StatusBadge({ status }) {
  const styles = {
    pending: "text-gold border-gold/50 bg-gold/10",
    confirmed: "text-racing2 border-racing2/50 bg-racing2/10",
    "in-service": "text-lime border-lime/50 bg-lime/10",
    completed: "text-ink border-line2 bg-white/5",
    cancelled: "text-alert border-alert/50 bg-alert/10"
  };
  return <span className={`inline-block border px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.16em] ${styles[status] || styles.pending}`}>
      {status}
    </span>;
}
function CardBlock({ card }) {
  if (!card) return null;
  if (card.type === "booking") {
    const a = card.appointment;
    return <div className="mt-3 border border-lime/35 bg-lime/5 p-4">
        <p className="mono-label mb-3 text-lime">✓ Booking confirmed</p>
        <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
          <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">Reference</dt>
          <dd className="text-right font-mono text-lime">{a.refCode}</dd>
          <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">Service</dt>
          <dd className="text-right text-ink">{a.service}</dd>
          <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">When</dt>
          <dd className="text-right text-ink">{labelDate(a.date)} · {a.time}</dd>
          <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">Technician</dt>
          <dd className="text-right text-ink">{a.technician}</dd>
          <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">Approval</dt>
          <dd className="text-right text-gold">Quote after inspection</dd>
        </dl>
        <p className="mt-3 border-t border-line pt-3 text-xs text-mute">
          Manage it any time in the <Link href="/portal" className="text-lime underline-offset-2 hover:underline">customer portal</Link> — or send Jane the reference to change it.
        </p>
      </div>;
  }
  if (card.type === "diagnosis") {
    const level = card.urgencyLevel;
    const urgencyColor = level >= 5 ? "text-alert border-alert/50" : level >= 4 ? "text-gold border-gold/50" : "text-racing2 border-racing2/50";
    return <div className="mt-3 border border-line bg-pit/60 p-4">
        <p className="mono-label mb-3">Diagnostic report</p>
        <div className="space-y-3">
          {card.findings.map((f) => <div key={f.cause}>
              <div className="mb-1 flex items-baseline justify-between gap-3">
                <p className="text-sm leading-snug text-ink">{f.cause}</p>
                <span className="shrink-0 font-mono text-[11px] text-lime">{f.confidence}%</span>
              </div>
              <div className="h-1 w-full bg-raise">
                <div className="h-full bg-gradient-to-r from-racing to-lime transition-all duration-700" style={{ width: `${f.confidence}%` }} />
              </div>
            </div>)}
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-line pt-3">
          <span className={`border px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest ${urgencyColor}`}>⚠ {card.urgency}</span>
          <span className="border border-line2 px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest text-gold">Est. {card.cost}</span>
        </div>
      </div>;
  }
  if (card.type === "status") {
    const a = card.appointment;
    return <div className="mt-3 border border-line bg-pit/60 p-4">
        <div className="mb-3 flex items-center justify-between gap-3">
          <span className="font-mono text-xs tracking-widest text-lime">{a.refCode}</span>
          <StatusBadge status={a.status} />
        </div>
        <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
          <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">Service</dt>
          <dd className="text-right text-ink">{a.service}</dd>
          <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">When</dt>
          <dd className="text-right text-ink">{labelDate(a.date)} · {a.time}</dd>
          <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">Technician</dt>
          <dd className="text-right text-ink">{a.technician || "\u2014"}</dd>
          <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">Vehicle</dt>
          <dd className="text-right text-ink">{a.vehicle || "\u2014"}</dd>
        </dl>
      </div>;
  }
  if (card.type === "vin") {
    return <div className="mt-3 border border-line bg-pit/60 p-4">
        <p className="mono-label mb-3">JLR build decode</p>
        <dl className="space-y-1.5 text-sm">
          {Object.entries(card.data).map(([k, v]) => <div key={k} className="flex justify-between gap-4">
              <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">{k}</dt>
              <dd className="text-right text-ink">{v}</dd>
            </div>)}
        </dl>
      </div>;
  }
  return null;
}
function AssistantPage() {
  const [messages, setMessages] = useState(
    () => WELCOME_REPLIES.map((text) => ({ role: "assistant", text }))
  );
  const [quicks, setQuicks] = useState(WELCOME_QUICK);
  const [typing, setTyping] = useState(false);
  const [input, setInput] = useState("");
  const [convId, setConvId] = useState(null);
  const [error, setError] = useState(null);
  const [voiceSupported, setVoiceSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const endRef = useRef(null);
  const recognitionRef = useRef(null);
  const busy = useRef(false);
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, typing]);
  useEffect(() => {
    const w = window;
    const Recognition = w.SpeechRecognition || w.webkitSpeechRecognition;
    const supported = Boolean(Recognition) && "speechSynthesis" in window;
    setVoiceSupported(supported);
    if (!Recognition) return;
    const recognition = new Recognition();
    recognition.lang = "en-US";
    recognition.interimResults = true;
    recognition.continuous = false;
    recognition.onstart = () => setListening(true);
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognition.onresult = (event) => {
      let transcript = "";
      for (let i = 0; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      setInput(transcript.trim());
    };
    recognitionRef.current = recognition;
    return () => {
      recognition.stop();
      window.speechSynthesis?.cancel();
    };
  }, []);
  const speak = useCallback((texts) => {
    if (!voiceEnabled || typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const merged = texts.map(cleanForSpeech).filter(Boolean).join(". ");
    if (!merged) return;
    const utterance = new SpeechSynthesisUtterance(merged);
    utterance.lang = "en-US";
    utterance.rate = 0.94;
    utterance.pitch = 0.92;
    utterance.onstart = () => setSpeaking(true);
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
  }, [voiceEnabled]);
  const toggleListening = () => {
    const recognition = recognitionRef.current;
    if (!recognition) {
      setError("Voice input is not supported in this browser. Try Chrome or Edge.");
      return;
    }
    if (listening) recognition.stop();
    else {
      setError(null);
      recognition.start();
    }
  };
  const toggleVoiceOutput = () => {
    const next = !voiceEnabled;
    setVoiceEnabled(next);
    if (!next) {
      window.speechSynthesis?.cancel();
      setSpeaking(false);
    }
  };
  const send = useCallback(async (raw) => {
    const message = raw.trim();
    if (!message || busy.current) return;
    busy.current = true;
    setError(null);
    setInput("");
    setMessages((m) => [...m, { role: "user", text: message }]);
    setTyping(true);
    try {
      const res = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, conversationId: convId })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed");
      setConvId(data.conversationId);
      const replies = data.replies;
      setMessages((m) => [
        ...m,
        ...replies.map((text) => ({ role: "assistant", text, card: data.card }))
      ]);
      setQuicks(data.quickReplies || []);
      speak(replies);
    } catch (e) {
      setError(e.message || "Something went wrong \u2014 please try again.");
    } finally {
      setTyping(false);
      busy.current = false;
    }
  }, [convId]);
  return <section className="relative min-h-[calc(100vh-97px)] overflow-hidden">
      <div className="carbon absolute inset-0 opacity-40" aria-hidden />
      <div className="glow-lime pointer-events-none absolute -left-32 top-24 h-[480px] w-[680px]" aria-hidden />
      <div className="relative mx-auto grid max-w-[1400px] gap-8 px-4 py-12 md:px-8 lg:grid-cols-[340px_1fr]">
        {
    /* rail */
  }
        <aside className="hidden lg:block">
          <div className="sticky top-32 space-y-5">
            <div className="panel relative overflow-hidden p-6">
              <div className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-racing via-lime to-racing" />
              <div className="flex items-center gap-4">
                <span className="relative grid h-14 w-14 place-items-center border border-lime/50 bg-lime/10 font-display text-2xl font-bold text-lime">
                  J
                  <span className="absolute -bottom-1 -right-1 h-3 w-3 rounded-full border-2 border-panel bg-lime pulse-dot" />
                </span>
                <div>
                  <p className="font-display text-xl font-bold uppercase tracking-wide text-ink">Jane</p>
                  <p className="font-mono text-[10px] uppercase tracking-widest text-racing2">AI service assistant · online</p>
                </div>
              </div>
              <ul className="mt-6 space-y-3.5">
                {[
    ["chat", "Books & reschedules in plain language"],
    ["gauge", "Triages symptoms with urgency + cost bands"],
    ["calendar", "Checks live bay availability"],
    ["key", "Decodes VINs & runs recall checks"],
    ["shield", "Escalates to a human advisor on request"]
  ].map(([icon, t]) => <li key={t} className="flex gap-3 text-sm text-mute">
                    <Icon name={icon} size={16} className="mt-0.5 shrink-0 text-lime" />
                    {t}
                  </li>)}
              </ul>
            </div>
            <div className="border border-line bg-panel/50 p-6">
              <p className="mono-label mb-4">Workshop now</p>
              <div className="space-y-2.5 font-mono text-[11px] uppercase tracking-widest text-mute">
                <p className="flex justify-between"><span>Bay load</span><span className="text-lime">6 / 8</span></p>
                <p className="flex justify-between"><span>Avg. response</span><span className="text-ink">~2s</span></p>
                <p className="flex justify-between"><span>Hours</span><span className="text-ink">08:30–18:00</span></p>
              </div>
              <p className="mt-4 border-t border-line pt-4 text-xs leading-relaxed text-dim">
                Prefer a human? {WORKSHOP.phone} · WhatsApp {WORKSHOP.whatsapp}
              </p>
            </div>
            <p className="font-mono text-[9px] uppercase leading-relaxed tracking-[0.18em] text-dim">
              Powered by GPT · RAG over JLR manuals · 25-yr failure database
            </p>
          </div>
        </aside>

        {
    /* chat */
  }
        <Reveal className="min-w-0">
          <div className="panel flex h-[calc(100vh-190px)] min-h-[560px] flex-col overflow-hidden">
            {
    /* chat header */
  }
            <div className="flex items-center justify-between gap-4 border-b border-line bg-pit/50 px-5 py-4">
              <div className="flex items-center gap-3">
                <span className="grid h-9 w-9 place-items-center border border-lime/50 bg-lime/10 font-display font-bold text-lime lg:hidden">J</span>
                <div>
                  <p className="font-display text-sm font-bold uppercase tracking-wider text-ink">
                    Jane — Baydoun AI Assistant
                  </p>
                  <p className="font-mono text-[10px] uppercase tracking-widest text-racing2">
                    ● Online · replies in ~2s · conversation #{convId ?? "new"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
    type="button"
    onClick={toggleVoiceOutput}
    disabled={!voiceSupported}
    aria-pressed={voiceEnabled}
    aria-label={voiceEnabled ? "Turn Jane voice off" : "Turn Jane voice on"}
    title={voiceSupported ? voiceEnabled ? "Voice replies on" : "Voice replies off" : "Voice is not supported in this browser"}
    className={`hidden items-center gap-2 border px-2.5 py-1.5 font-mono text-[9px] uppercase tracking-widest transition-all sm:inline-flex ${voiceEnabled ? "border-lime/70 bg-lime/10 text-lime" : "border-line2 text-mute hover:border-lime/50 hover:text-lime"} disabled:cursor-not-allowed disabled:opacity-35`}
  >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                    <path d="M11 5 6 9H3v6h3l5 4V5Z" />
                    <path d="M15.5 8.5a5 5 0 0 1 0 7" />
                    <path d="M18.5 5.5a9 9 0 0 1 0 13" />
                  </svg>
                  {speaking ? "Speaking" : voiceEnabled ? "Voice on" : "Voice"}
                </button>
                <span className="hidden border border-line2 px-2.5 py-1.5 font-mono text-[9px] uppercase tracking-widest text-mute sm:block">
                  24/7 · EN / AR
                </span>
              </div>
            </div>

            {
    /* messages */
  }
            <div className="flex-1 space-y-4 overflow-y-auto px-4 py-6 md:px-6">
              {messages.map((m, i) => <div key={i} className={`anim-rise flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[86%] md:max-w-[72%] ${m.role === "user" ? "text-right" : ""}`}>
                    <p className="mb-1 font-mono text-[9px] uppercase tracking-[0.2em] text-dim">
                      {m.role === "user" ? "You" : "Jane \xB7 AI"}
                    </p>
                    <div
    className={`inline-block w-auto px-4 py-3 text-left text-[15px] leading-relaxed ${m.role === "user" ? "border border-lime/30 bg-lime/10 text-ink" : "border border-line bg-panel2 text-ink/90"}`}
  >
                      {renderText(m.text)}
                      {m.card && <CardBlock card={m.card} />}
                    </div>
                  </div>
                </div>)}
              {typing && <div className="flex justify-start">
                  <div className="border border-line bg-panel2 px-4 py-3.5">
                    <TypingDots />
                  </div>
                </div>}
              {error && <p className="border border-alert/40 bg-alert/10 px-4 py-3 text-sm text-alert">{error}</p>}
              <div ref={endRef} />
            </div>

            {
    /* quick replies */
  }
            {quicks.length > 0 && <div className="flex flex-wrap gap-2 border-t border-line bg-pit/40 px-4 py-3 md:px-6">
                {quicks.map((q) => <button key={q} onClick={() => send(q)} className="chip !normal-case !tracking-normal hover:text-lime">
                    {q}
                  </button>)}
              </div>}

            {
    /* input */
  }
            <form
    onSubmit={(e) => {
      e.preventDefault();
      send(input);
    }}
    className="flex items-center gap-3 border-t border-line bg-pit/60 px-4 py-4 md:px-6"
  >
              <input
    value={input}
    onChange={(e) => setInput(e.target.value)}
    maxLength={600}
    placeholder={listening ? "Listening\u2026 speak naturally" : "e.g. \u201CBook air suspension for my Defender, Thursday morning\u201D"}
    aria-label="Message Jane"
    className="min-w-0 flex-1 border border-line2 bg-panel px-4 py-3 text-[15px] text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
  />
              <button
    type="button"
    onClick={toggleListening}
    disabled={!voiceSupported || typing}
    aria-pressed={listening}
    aria-label={listening ? "Stop voice input" : "Start voice input"}
    title={voiceSupported ? listening ? "Stop listening" : "Speak to Jane" : "Voice input is not supported in this browser"}
    className={`grid h-12 w-12 shrink-0 place-items-center border transition-all ${listening ? "border-lime bg-lime/10 text-lime shadow-[0_0_24px_-8px_rgba(201,241,88,0.85)]" : "border-line2 text-mute hover:border-lime/60 hover:text-lime"} disabled:cursor-not-allowed disabled:opacity-35`}
  >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                  <path d="M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3Z" />
                  <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
                  <path d="M12 19v3" />
                </svg>
              </button>
              <button type="submit" disabled={!input.trim() || typing} className="btn-primary !px-5 disabled:cursor-not-allowed disabled:opacity-40" aria-label="Send message">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                  <path d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7Z" />
                </svg>
                <span className="hidden sm:inline">Send</span>
              </button>
            </form>
            <div className="border-t border-line/60 bg-pit/40 px-4 py-2 text-center font-mono text-[9px] uppercase tracking-[0.18em] text-dim md:px-6">
              {voiceSupported ? listening ? "Voice input active \xB7 speak clearly, then press send" : voiceEnabled ? "Voice input ready \xB7 Jane voice replies enabled" : "Voice input ready \xB7 enable voice replies from the header" : "Voice features are best supported in Chrome or Edge"}
            </div>
          </div>
          <p className="mt-4 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-dim">
            Jane can make mistakes — a master technician confirms every job card. When we part ways: “{CLOSING.slice(0, 60)}…”
          </p>
        </Reveal>
      </div>
    </section>;
}
export {
  AssistantPage as default
};
