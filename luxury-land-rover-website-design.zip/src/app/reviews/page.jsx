"use client";
import { useCallback, useEffect, useState } from "react";
import { Icon, Reveal, Scramble } from "@/components/fx";
function ReviewsPage() {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: "", vehicle: "", rating: 5, body: "" });
  const [err, setErr] = useState(null);
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    const res = await fetch("/api/reviews");
    if (res.ok) {
      const d = await res.json();
      setReviews(d.reviews);
    }
    setLoading(false);
  }, []);
  useEffect(() => {
    load();
  }, [load]);
  const avg = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : "\u2014";
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setErr(d.error || "Could not save your review.");
    setSent(true);
    setForm({ name: "", vehicle: "", rating: 5, body: "" });
    load();
  };
  return <>
      <section className="relative overflow-hidden border-b border-line">
        <div className="carbon absolute inset-0 opacity-50" aria-hidden />
        <div className="relative mx-auto max-w-[1400px] px-4 pb-16 pt-20 md:px-8">
          <p className="mono-label mb-6 flex items-center gap-3">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime pulse-dot" /> {reviews.length || "\u2026"} verified owner reviews
          </p>
          <h1 className="font-display text-6xl font-bold uppercase leading-[0.88] text-ink md:text-8xl">
            <Scramble text="Owner" /> <span className="text-lime"><Scramble text="verdicts" delay={200} /></span>
          </h1>
          <div className="mt-8 flex items-center gap-5">
            <p className="font-display text-6xl font-bold text-gold">{avg}</p>
            <div>
              <p className="flex gap-1 text-gold">
                {Array.from({ length: 5 }).map((_, i) => <Icon key={i} name="star" size={18} className="fill-gold stroke-none" />)}
              </p>
              <p className="mt-1 font-mono text-[10px] uppercase tracking-widest text-dim">Google · WhatsApp · Website</p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-[1400px] gap-12 px-4 py-16 md:px-8 lg:grid-cols-[1.5fr_1fr]">
        <div>
          {loading ? <div className="grid h-64 place-items-center">
              <div className="h-10 w-10 animate-[spinSlow_1.2s_linear_infinite] border border-line2 border-t-lime" />
            </div> : <div className="space-y-5">
              {reviews.map((r, i) => <Reveal key={r.id} delay={Math.min(i * 60, 300)}>
                  <article className="border border-line bg-panel/70 p-6 transition-colors duration-300 hover:border-line2 md:p-7">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <p className="flex gap-1 text-gold">
                        {Array.from({ length: 5 }).map((_, s) => <Icon key={s} name="star" size={14} className={s < r.rating ? "fill-gold stroke-none" : "stroke-dim"} />)}
                      </p>
                      <span className="font-mono text-[9px] uppercase tracking-widest text-dim">{r.source}</span>
                    </div>
                    <p className="mt-4 text-base leading-relaxed text-ink">“{r.body}”</p>
                    <p className="mt-4 font-mono text-[11px] uppercase tracking-widest text-mute">
                      <span className="text-lime">{r.name}</span>{r.vehicle ? ` \xB7 ${r.vehicle}` : ""}
                    </p>
                  </article>
                </Reveal>)}
            </div>}
        </div>

        <aside>
          <div className="panel sticky top-32 p-7 md:p-8">
            <p className="font-display text-2xl font-bold uppercase text-ink">Owned the experience?</p>
            <p className="mt-2 text-sm leading-relaxed text-mute">Tell other Land Rover owners what actually happened in the bay.</p>
            {sent && <p className="mt-4 border border-lime/40 bg-lime/10 px-4 py-3 text-sm text-lime">
                Thank you — your review is live. 🙏
              </p>}
            <form onSubmit={submit} className="mt-6 space-y-4">
              <label className="block">
                <span className="mono-label">Name</span>
                <input
    required
    value={form.name}
    onChange={(e) => setForm({ ...form, name: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="Nabil G."
  />
              </label>
              <label className="block">
                <span className="mono-label">Vehicle</span>
                <input
    value={form.vehicle}
    onChange={(e) => setForm({ ...form, vehicle: e.target.value })}
    className="mt-2 w-full border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="Defender 110"
  />
              </label>
              <div>
                <span className="mono-label">Rating</span>
                <div className="mt-2 flex gap-2">
                  {[1, 2, 3, 4, 5].map((n) => <button
    type="button"
    key={n}
    onClick={() => setForm({ ...form, rating: n })}
    aria-label={`${n} stars`}
    className={`transition-transform duration-200 hover:scale-110 ${n <= form.rating ? "text-gold" : "text-raise"}`}
  >
                      <Icon name="star" size={26} className="fill-current stroke-none" />
                    </button>)}
                </div>
              </div>
              <label className="block">
                <span className="mono-label">Your review</span>
                <textarea
    required
    rows={4}
    value={form.body}
    onChange={(e) => setForm({ ...form, body: e.target.value })}
    className="mt-2 w-full resize-none border border-line2 bg-pit px-4 py-3 text-ink placeholder:text-dim focus:border-lime/60 focus:outline-none"
    placeholder="What did they find, fix, and how did it feel?"
  />
              </label>
              {err && <p className="border border-alert/40 bg-alert/10 px-3 py-2.5 text-sm text-alert">{err}</p>}
              <button type="submit" disabled={busy} className="btn-primary w-full justify-center disabled:opacity-50">
                {busy ? "Publishing\u2026" : "Publish review"}
              </button>
            </form>
          </div>
        </aside>
      </section>
    </>;
}
export {
  ReviewsPage as default
};
