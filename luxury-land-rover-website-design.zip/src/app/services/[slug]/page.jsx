import Link from "next/link";
import { notFound } from "next/navigation";
import { SERVICES, serviceBySlug } from "@/lib/services";
import { Icon, Reveal, Scramble } from "@/components/fx";
function generateStaticParams() {
  return SERVICES.map((s) => ({ slug: s.slug }));
}
async function generateMetadata({ params }) {
  const { slug } = await params;
  const s = serviceBySlug(slug);
  return { title: s ? `${s.name} \u2014 Baydoun Land Rover` : "Service \u2014 Baydoun Land Rover" };
}
const QUOTES = [
  { text: "Quoted before work, delivered to the quote, finished a day early.", name: "Rana K.", car: "Discovery Sport" },
  { text: "The digital report with photos is something every shop should do.", name: "Omar H.", car: "Range Rover Sport" },
  { text: "Booked through Jane at midnight, collected by their truck at 8am.", name: "Dana F.", car: "Defender 130" }
];
async function ServiceDetail({ params }) {
  const { slug } = await params;
  const s = serviceBySlug(slug);
  if (!s) notFound();
  const related = SERVICES.filter((x) => x.slug !== s.slug).slice(0, 3);
  const idx = SERVICES.indexOf(s);
  return <>
      {
    /* hero */
  }
      <section className="relative overflow-hidden border-b border-line">
        <img src={s.image} alt={s.alt} className="absolute inset-0 h-full w-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/60 to-bg/30" />
        <div className="carbon absolute inset-0 opacity-30" aria-hidden />
        <div className="relative mx-auto max-w-[1400px] px-4 pb-14 pt-20 md:px-8">
          <Link href="/services" className="mono-label mb-8 inline-flex items-center gap-2 transition-colors hover:text-lime">
            <Icon name="arrow" size={13} className="rotate-180" /> All services
          </Link>
          <p className="mono-label mb-4">
            <span className="text-lime">{String(idx + 1).padStart(2, "0")} / 13</span> · {s.tag}
          </p>
          <h1 className="max-w-4xl font-display text-6xl font-bold uppercase leading-[0.88] text-ink md:text-8xl">
            <Scramble text={s.name} />
          </h1>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-mute md:text-lg">{s.summary}</p>
        </div>
      </section>

      <section className="mx-auto grid max-w-[1400px] gap-14 px-4 py-16 md:px-8 lg:grid-cols-[1fr_380px] lg:py-24">
        {
    /* main column */
  }
        <div className="order-2 lg:order-1">
          <Reveal>
            <div className="overflow-hidden border border-line" data-mag>
              <img src={s.image} alt={s.alt} className="anim-kenburns block aspect-[16/8] w-full object-cover" />
            </div>
          </Reveal>

          <Reveal delay={100}>
            <p className="mt-10 max-w-2xl text-base leading-relaxed text-mute md:text-lg">{s.desc}</p>
          </Reveal>

          {
    /* process */
  }
          <div className="mt-16">
            <h2 className="font-display text-3xl font-bold uppercase text-ink md:text-4xl">
              How the work <span className="text-lime">happens</span>
            </h2>
            <div className="mt-8 grid gap-px border border-line bg-line sm:grid-cols-2">
              {s.process.map((p, i) => <div key={p.title} className="group relative bg-panel p-7 transition-colors duration-500 hover:bg-panel2">
                  <span className="font-mono text-xs tracking-widest text-lime">STEP {String(i + 1).padStart(2, "0")}</span>
                  <h3 className="mt-3 font-display text-xl font-semibold uppercase tracking-wide text-ink">{p.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-mute">{p.body}</p>
                  <span className="absolute right-6 top-6 h-2 w-2 rotate-45 border border-line2 transition-colors duration-300 group-hover:border-lime group-hover:bg-lime" />
                </div>)}
            </div>
          </div>

          {
    /* AI recommendation */
  }
          <Reveal delay={100}>
            <div className="mt-16 border border-lime/25 bg-lime/5 p-7 md:p-8">
              <p className="mono-label mb-4 flex items-center gap-2 text-lime">
                <span className="h-1.5 w-1.5 rounded-full bg-lime pulse-dot" /> Jane's recommendation
              </p>
              <p className="max-w-2xl text-base leading-relaxed text-ink">
                “Most {s.name.toLowerCase()} work on modern Land Rovers is caught early by the
                40-point inspection. If you're hearing or seeing anything unusual, let me triage
                it free — I'll rank the urgency and book the right bay, not just the next one.”
              </p>
              <Link href={`/assistant?service=${s.slug}`} className="btn-primary mt-6 !py-3 text-[13px]">
                <Icon name="chat" size={16} /> Book {s.name} with Jane
              </Link>
            </div>
          </Reveal>

          {
    /* testimonials */
  }
          <div className="mt-16">
            <h2 className="font-display text-3xl font-bold uppercase text-ink">
              Owners on this <span className="text-outline">service</span>
            </h2>
            <div className="mt-8 space-y-4">
              {QUOTES.map((q, i) => <Reveal key={q.name} delay={i * 90}>
                  <figure className="flex flex-wrap items-baseline gap-x-4 gap-y-2 border-b border-line pb-4">
                    <blockquote className="text-base text-ink">“{q.text}”</blockquote>
                    <figcaption className="font-mono text-[10px] uppercase tracking-widest text-dim">
                      <span className="text-gold">{q.name}</span> · {q.car}
                    </figcaption>
                  </figure>
                </Reveal>)}
            </div>
          </div>
        </div>

        {
    /* sticky spec rail */
  }
        <aside className="order-1 lg:order-2">
          <div className="sticky top-28 space-y-4">
            <div className="panel p-7">
              <p className="mono-label mb-5">Service specification</p>
              <dl className="space-y-4 text-sm">
                <div className="flex items-baseline justify-between gap-4 border-b border-line pb-3">
                  <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">Inspection</dt>
                  <dd className="text-right text-ink">Advisor-led intake</dd>
                </div>
                <div className="flex justify-between gap-4 border-b border-line pb-3">
                  <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">Documentation</dt>
                  <dd className="text-right text-ink">Photo report + digital record</dd>
                </div>
                <div className="flex justify-between gap-4 border-b border-line pb-3">
                  <dt className="font-mono text-[10px] uppercase tracking-widest text-dim">Warranty</dt>
                  <dd className="text-right text-ink">{s.warranty}</dd>
                </div>
              </dl>
              <p className="mono-label mb-4 mt-7">Includes</p>
              <ul className="space-y-3">
                {s.includes.map((inc) => <li key={inc} className="flex gap-3 text-sm leading-relaxed text-mute">
                    <Icon name="check" size={15} className="mt-0.5 shrink-0 text-lime" />
                    {inc}
                  </li>)}
              </ul>
              <Link href={`/assistant?service=${s.slug}`} className="btn-primary mt-8 w-full justify-center">
                <Icon name="calendar" size={16} /> Book this service
              </Link>
              <Link href="/assistant" className="btn-ghost mt-3 w-full justify-center !py-3 text-[12px]">
                Ask Jane a question
              </Link>
            </div>
            <div className="border border-line bg-panel/50 p-6">
              <p className="mono-label mb-4">Related disciplines</p>
              <ul className="space-y-3">
                {related.map((r) => <li key={r.slug}>
                    <Link href={`/services/${r.slug}`} className="group flex items-center justify-between gap-3 text-sm text-mute transition-colors hover:text-lime">
                      {r.name}
                      <Icon name="arrow" size={14} className="transition-transform duration-300 group-hover:translate-x-1" />
                    </Link>
                  </li>)}
              </ul>
            </div>
          </div>
        </aside>
      </section>
    </>;
}
export {
  ServiceDetail as default,
  generateMetadata,
  generateStaticParams
};
