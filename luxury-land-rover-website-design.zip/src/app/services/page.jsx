"use client";
import Link from "next/link";
import { useState } from "react";
import { SERVICES } from "@/lib/services";
import { Icon, Reveal, Scramble } from "@/components/fx";
const CATS = {
  "engine-diagnostics": "Diagnostics",
  "transmission-repair": "Mechanical",
  suspension: "Mechanical",
  "air-suspension": "Mechanical",
  "electrical-systems": "Electronics",
  "ecu-programming": "Electronics",
  "brake-systems": "Mechanical",
  "off-road-upgrades": "Enhancement",
  "performance-upgrades": "Enhancement",
  "battery-systems": "Electronics",
  "hybrid-systems": "Electronics",
  "software-updates": "Electronics",
  "preventive-maintenance": "Care"
};
const FILTERS = ["All", "Diagnostics", "Mechanical", "Electronics", "Enhancement", "Care"];
function ServicesPage() {
  const [filter, setFilter] = useState("All");
  const list = SERVICES.filter((s) => filter === "All" || CATS[s.slug] === filter);
  return <>
      <section className="relative overflow-hidden border-b border-line">
        <div className="carbon absolute inset-0 opacity-50" aria-hidden />
        <div className="glow-racing pointer-events-none absolute -top-32 right-10 h-[420px] w-[620px]" aria-hidden />
        <div className="relative mx-auto max-w-[1400px] px-4 pb-16 pt-20 md:px-8">
          <p className="mono-label mb-6 flex items-center gap-3">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-lime pulse-dot" />
            13 disciplines · one marque
          </p>
          <h1 className="font-display text-6xl font-bold uppercase leading-[0.88] text-ink md:text-8xl">
            <Scramble text="Service" />{" "}
            <span className="text-outline">
              <Scramble text="capabilities" delay={200} />
            </span>
          </h1>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-mute md:text-lg">
            Every system a Land Rover has — engineered, repaired and calibrated by people who do
            nothing else. Transparent pricing, genuine parts, warranty in writing.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-4 py-14 md:px-8">
        <div className="mb-12 flex flex-wrap gap-2.5">
          {FILTERS.map((f) => <button
    key={f}
    onClick={() => setFilter(f)}
    className={`px-4 py-2 font-mono text-[11px] uppercase tracking-[0.18em] transition-all duration-300 ${filter === f ? "bg-lime text-pit" : "border border-line2 text-mute hover:border-lime/50 hover:text-ink"}`}
  >
              {f}
              <span className="ml-2 opacity-60">
                {f === "All" ? SERVICES.length : SERVICES.filter((s) => CATS[s.slug] === f).length}
              </span>
            </button>)}
        </div>

        <div className="space-y-px border border-line bg-line">
          {list.map((s, i) => <Reveal key={s.slug} delay={Math.min(i * 60, 300)}>
              <Link
    href={`/services/${s.slug}`}
    className="group relative grid grid-cols-[auto_1fr] items-center gap-5 bg-panel px-5 py-6 transition-colors duration-500 hover:bg-panel2 md:grid-cols-[70px_1.2fr_1.6fr_auto_auto] md:gap-8 md:px-8"
    data-mag
  >
                <span className="font-mono text-xs tracking-widest text-dim transition-colors duration-300 group-hover:text-lime">
                  {String(SERVICES.indexOf(s) + 1).padStart(2, "0")}
                </span>
                <div>
                  <h2 className="font-display text-2xl font-bold uppercase leading-none text-ink transition-colors duration-300 group-hover:text-lime md:text-3xl">
                    {s.name}
                  </h2>
                  <p className="mono-label mt-2 !text-[10px]">{s.tag}</p>
                </div>
                <p className="col-span-2 hidden text-sm leading-relaxed text-mute md:col-span-1 md:block">
                  {s.summary}
                </p>
                <div className="hidden text-right md:block">
                  <p className="font-mono text-xs uppercase tracking-widest text-gold">JLR-only bay</p>
                  <p className="mt-1 font-mono text-[10px] uppercase tracking-widest text-dim">Advisor-led intake</p>
                </div>
                <span className="absolute right-5 grid h-11 w-11 place-items-center border border-line2 text-mute transition-all duration-300 group-hover:border-lime group-hover:bg-lime group-hover:text-pit md:static">
                  <Icon name="arrow" size={17} />
                </span>
                <span className="pointer-events-none absolute right-24 top-1/2 hidden h-24 w-36 -translate-y-1/2 scale-90 overflow-hidden border border-line opacity-0 transition-all duration-500 group-hover:scale-100 group-hover:opacity-100 xl:block">
                  <img src={s.image} alt="" loading="lazy" className="h-full w-full object-cover" />
                </span>
              </Link>
            </Reveal>)}
        </div>

        <Reveal delay={200}>
          <div className="mt-14 flex flex-col items-start justify-between gap-6 border border-line bg-panel/60 p-8 md:flex-row md:items-center">
            <div>
              <p className="mono-label mb-2">Not sure what it needs?</p>
              <p className="font-display text-3xl font-bold uppercase text-ink">
                Describe the symptom — <span className="text-lime">Jane will triage it</span>
              </p>
            </div>
            <Link href="/assistant" className="btn-primary shrink-0">
              <Icon name="chat" size={18} /> Ask the AI mechanic
            </Link>
          </div>
        </Reveal>
      </section>
    </>;
}
export {
  ServicesPage as default
};
