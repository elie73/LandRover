import { Oswald, Instrument_Sans, IBM_Plex_Mono } from "next/font/google";
import { Nav, Footer, AssistantFab, WhatsAppFab } from "@/components/chrome";
import { Cursor } from "@/components/fx";
import "./globals.css";
const display = Oswald({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-display",
  display: "swap"
});
const body = Instrument_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-body",
  display: "swap"
});
const mono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-mono",
  display: "swap"
});
const metadata = {
  title: "Baydoun Land Rover \u2014 Master Service Atelier",
  description: "The world's most advanced Land Rover specialist. AI diagnostics, master technicians, genuine parts, and a concierge service experience.",
  openGraph: {
    title: "Baydoun Land Rover \u2014 Master Service Atelier",
    description: "Precision engineering meets British luxury. Book with our AI service assistant."
  }
};
function RootLayout({ children }) {
  return <html lang="en" className={`${display.variable} ${body.variable} ${mono.variable}`}>
      <body className="noise bg-bg text-ink antialiased">
        <Nav />
        <main className="relative z-[1]">{children}</main>
        <Footer />
        <AssistantFab />
        <WhatsAppFab />
        <Cursor />
        <div aria-hidden className="pointer-events-none fixed inset-0 z-[95]">
          <div className="absolute -top-40 left-1/4 h-[480px] w-[720px] glow-racing opacity-70" />
        </div>
      </body>
    </html>;
}
export {
  RootLayout as default,
  metadata
};
