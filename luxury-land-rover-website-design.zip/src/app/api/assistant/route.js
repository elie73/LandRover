import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { conversations } from "@/db/schema";
import { getSessionCustomerId } from "@/lib/auth";
import { handleAssistant, WELCOME_REPLIES } from "@/lib/ai";
export const dynamic = "force-dynamic";
async function POST(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const message = (body.message || "").trim();
    if (!message || message.length > 600)
      return NextResponse.json({ error: "Message must be 1\u2013600 characters." }, { status: 400 });
    const customerId = await getSessionCustomerId();
    let convId = body.conversationId ?? null;
    let state = {};
    let existing = [];
    let visitorName = null;
    if (convId) {
      const rows = await db.select().from(conversations).where(eq(conversations.id, convId)).limit(1);
      if (rows.length) {
        state = rows[0].state || {};
        existing = rows[0].messages || [];
        visitorName = rows[0].visitorName;
      } else {
        convId = null;
      }
    }
    if (!convId) {
      const [created] = await db.insert(conversations).values({
        customerId,
        visitorName: null,
        intent: "new",
        state: {},
        messages: WELCOME_REPLIES.map((text) => ({ role: "assistant", text }))
      }).returning();
      convId = created.id;
      existing = created.messages || [];
    }
    const result = await handleAssistant(message, {
      id: convId,
      customerId,
      state
    });
    const messages = [
      ...existing,
      { role: "user", text: message },
      ...result.replies.map((text) => ({ role: "assistant", text, card: result.card }))
    ];
    const [updated] = await db.update(conversations).set({
      state: result.state,
      intent: result.intent,
      messages,
      visitorName: visitorName ?? result.state?.slots?.name ?? null,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(conversations.id, convId)).returning();
    return NextResponse.json({
      conversationId: updated.id,
      replies: result.replies,
      card: result.card ?? null,
      quickReplies: result.quickReplies,
      intent: result.intent
    });
  } catch (e) {
    console.error("assistant error", e);
    return NextResponse.json({ error: "The assistant hit a snag \u2014 please try again." }, { status: 500 });
  }
}
export {
  POST
};
