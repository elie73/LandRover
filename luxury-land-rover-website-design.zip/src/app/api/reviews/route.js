import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { reviews } from "@/db/schema";
export const dynamic = "force-dynamic";
async function GET() {
  const rows = await db.execute(
    sql`SELECT * FROM reviews ORDER BY created_at DESC LIMIT 40`
  );
  return NextResponse.json({ reviews: rows.rows });
}
async function POST(req) {
  const body = await req.json().catch(() => ({}));
  const name = (body.name || "").trim();
  const text = (body.body || "").trim();
  const rating = Number(body.rating);
  if (name.length < 2) return NextResponse.json({ error: "Please tell us your name." }, { status: 400 });
  if (text.length < 10) return NextResponse.json({ error: "A few more words would help other owners." }, { status: 400 });
  if (!Number.isInteger(rating) || rating < 1 || rating > 5)
    return NextResponse.json({ error: "Rating must be 1\u20135." }, { status: 400 });
  const [row] = await db.insert(reviews).values({ name, vehicle: body.vehicle?.trim() || null, rating, body: text, source: "Website" }).returning();
  return NextResponse.json({ ok: true, review: row });
}
export {
  GET,
  POST
};
