import { NextResponse } from "next/server";
import { db } from "@/db";
import { contacts } from "@/db/schema";
export const dynamic = "force-dynamic";
async function POST(req) {
  const body = await req.json().catch(() => ({}));
  const name = (body.name || "").trim();
  const message = (body.message || "").trim();
  if (name.length < 2) return NextResponse.json({ error: "Please add your name." }, { status: 400 });
  if (message.length < 5) return NextResponse.json({ error: "Message is too short." }, { status: 400 });
  await db.insert(contacts).values({
    name,
    email: body.email?.trim() || null,
    phone: body.phone?.trim() || null,
    subject: body.subject?.trim() || null,
    message
  });
  return NextResponse.json({ ok: true });
}
export {
  POST
};
