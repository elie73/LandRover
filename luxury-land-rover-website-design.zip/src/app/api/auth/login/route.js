import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { createSessionToken, SESSION_COOKIE, verifyPassword, getSessionCustomer } from "@/lib/auth";
export const dynamic = "force-dynamic";
async function POST(req) {
  const body = await req.json().catch(() => ({}));
  const email = (body.email || "").trim().toLowerCase();
  const password = body.password || "";
  if (!email || !password)
    return NextResponse.json({ error: "Email and password are required." }, { status: 400 });
  const rows = await db.select().from(customers).where(eq(customers.email, email)).limit(1);
  const customer = rows[0];
  if (!customer || !verifyPassword(password, customer.passwordHash))
    return NextResponse.json({ error: "Invalid credentials. Try the demo login below." }, { status: 401 });
  const token = createSessionToken(customer.id);
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7
  });
  return NextResponse.json({ ok: true, name: customer.name, tier: customer.tier });
}
async function GET() {
  const customer = await getSessionCustomer();
  if (!customer) return NextResponse.json({ user: null });
  return NextResponse.json({ user: { id: customer.id, name: customer.name, email: customer.email, tier: customer.tier } });
}
export {
  GET,
  POST
};
