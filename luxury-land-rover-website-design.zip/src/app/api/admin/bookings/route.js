import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { appointments, customers, serviceRecords, vehicles } from "@/db/schema";
export const dynamic = "force-dynamic";
const parseCost = (value) => {
  if (value == null || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 ? Math.round(n) : null;
};
const parseYear = (label) => {
  const found = (label || "").match(/\b(19|20)\d{2}\b/)?.[0];
  return found ? Number(found) : (/* @__PURE__ */ new Date()).getFullYear();
};
async function registerServiceHistory(row) {
  const cost = row.estimate;
  if (!cost || cost <= 0) {
    throw new Error("Enter a cost before marking this appointment completed.");
  }
  let customerId = row.customerId;
  let vehicleId = row.vehicleId;
  if (!customerId) {
    const [customer] = await db.insert(customers).values({
      name: row.customerName || "Walk-in Customer",
      email: `walkin-${row.refCode.toLowerCase()}-${Date.now()}@baydoun.local`,
      passwordHash: "walk-in-no-login",
      phone: null,
      tier: "Walk-in"
    }).returning();
    customerId = customer.id;
  }
  if (!vehicleId) {
    const [vehicle] = await db.insert(vehicles).values({
      customerId,
      vin: `WORKSHOP-${row.refCode}`,
      model: row.vehicleLabel || "Land Rover",
      year: parseYear(row.vehicleLabel),
      plate: null,
      color: null,
      mileage: null
    }).returning();
    vehicleId = vehicle.id;
    await db.update(appointments).set({ customerId, vehicleId }).where(eq(appointments.id, row.id));
  }
  const invoiceNo = `INV-${row.refCode}`;
  const existing = await db.select().from(serviceRecords).where(eq(serviceRecords.invoiceNo, invoiceNo)).limit(1);
  const values = {
    vehicleId,
    invoiceNo,
    title: row.service,
    category: row.service,
    date: row.date,
    mileage: null,
    technician: row.technician,
    cost,
    status: "completed",
    notes: row.notes || `Completed from appointment ${row.refCode}`
  };
  if (existing[0]) {
    await db.update(serviceRecords).set(values).where(eq(serviceRecords.id, existing[0].id));
  } else {
    await db.insert(serviceRecords).values(values);
  }
}
async function GET() {
  const rows = await db.execute(
    sql`SELECT a.*, c.messages AS conversation
        FROM appointments a
        LEFT JOIN conversations c ON c.id = a.conversation_id
        ORDER BY a.date DESC, a.time ASC`
  );
  return NextResponse.json({ appointments: rows.rows });
}
async function PATCH(req) {
  const body = await req.json().catch(() => ({}));
  if (!body.id) return NextResponse.json({ error: "Booking id required." }, { status: 400 });
  const currentRows = await db.select().from(appointments).where(eq(appointments.id, body.id)).limit(1);
  const current = currentRows[0];
  if (!current) return NextResponse.json({ error: "Appointment not found." }, { status: 404 });
  const rawCost = body.cost ?? body.estimate;
  const cost = parseCost(rawCost);
  if (rawCost != null && cost === null) {
    return NextResponse.json({ error: "Cost must be a valid number." }, { status: 400 });
  }
  const nextStatus = body.status || current.status;
  const nextCost = cost ?? current.estimate;
  if (nextStatus === "completed" && (!nextCost || nextCost <= 0)) {
    return NextResponse.json({ error: "Enter a cost before marking this appointment completed." }, { status: 400 });
  }
  const set = {};
  if (body.status) set.status = body.status;
  if (body.technician) set.technician = body.technician;
  if (cost !== null) set.estimate = cost;
  if (!Object.keys(set).length) return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  const [row] = await db.update(appointments).set(set).where(eq(appointments.id, body.id)).returning();
  if (!row) return NextResponse.json({ error: "Not found." }, { status: 404 });
  if (row.status === "completed") {
    try {
      await registerServiceHistory(row);
    } catch (error) {
      return NextResponse.json(
        { error: error instanceof Error ? error.message : "Could not register service history." },
        { status: 400 }
      );
    }
  }
  return NextResponse.json({ ok: true, appointment: row });
}
async function DELETE(req) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Booking id required." }, { status: 400 });
  const [row] = await db.delete(appointments).where(eq(appointments.id, id)).returning();
  if (!row) return NextResponse.json({ error: "Appointment not found." }, { status: 404 });
  return NextResponse.json({ ok: true, appointment: row });
}
export {
  DELETE,
  GET,
  PATCH
};
