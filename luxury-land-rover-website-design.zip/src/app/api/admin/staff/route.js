import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appointments, technicians } from "@/db/schema";
export const dynamic = "force-dynamic";
const MAX = 5 * 1024 * 1024;
async function GET() {
  const staff = await db.select().from(technicians).orderBy(technicians.name);
  return NextResponse.json({ staff });
}
async function POST(req) {
  const form = await req.formData().catch(() => null);
  if (!form) return NextResponse.json({ error: "Invalid staff form." }, { status: 400 });
  const name = String(form.get("name") || "").trim();
  const role = String(form.get("role") || "Service Advisor").trim();
  const specialization = String(form.get("specialization") || "Owner care \xB7 Land Rover service").trim();
  const level = String(form.get("level") || "Certified").trim();
  const years = Number(form.get("years") || 1);
  const rating = String(form.get("rating") || "5.0").trim();
  let avatar = String(form.get("avatar") || "").trim();
  if (name.length < 2) return NextResponse.json({ error: "Staff name is required." }, { status: 400 });
  const file = form.get("photo");
  if (file instanceof File && file.size > 0) {
    if (!file.type.startsWith("image/"))
      return NextResponse.json({ error: "Staff photo must be an image." }, { status: 400 });
    if (file.size > MAX)
      return NextResponse.json({ error: "Staff photo must be under 5 MB." }, { status: 400 });
    const bytes = Buffer.from(await file.arrayBuffer());
    avatar = `data:${file.type};base64,${bytes.toString("base64")}`;
  }
  if (!avatar) {
    avatar = "https://images.pexels.com/photos/7564867/pexels-photo-7564867.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800";
  }
  const [row] = await db.insert(technicians).values({
    name,
    role,
    specialization: specialization || null,
    level: level || null,
    years: Number.isFinite(years) ? years : 1,
    rating: rating || "5.0",
    avatar
  }).returning();
  return NextResponse.json({ ok: true, staff: row });
}
async function DELETE(req) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Staff id required." }, { status: 400 });
  const existing = await db.select().from(technicians).where(eq(technicians.id, id)).limit(1);
  if (!existing.length) return NextResponse.json({ error: "Staff member not found." }, { status: 404 });
  await db.update(appointments).set({ technician: null }).where(eq(appointments.technician, existing[0].name));
  await db.delete(technicians).where(eq(technicians.id, id));
  return NextResponse.json({ ok: true });
}
export {
  DELETE,
  GET,
  POST
};
