import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
export const dynamic = "force-dynamic";
async function GET() {
  const [statusRows, revenueRows, techRows, countRows, aiRows] = await Promise.all([
    db.execute(
      sql`SELECT status, count(*)::text AS c FROM appointments GROUP BY status`
    ),
    db.execute(
      sql`SELECT to_char(date::date, 'Mon') AS mon,
                 sum(cost)::text AS total,
                 min(date::date) AS first
          FROM service_records
          GROUP BY mon, date_part('month', date::date), date_part('year', date::date)
          ORDER BY first`
    ),
    db.execute(
      sql`SELECT technician AS name, count(*)::text AS c
          FROM appointments
          WHERE status <> 'cancelled' AND technician IS NOT NULL
          GROUP BY technician ORDER BY c DESC`
    ),
    db.execute(
      sql`SELECT count(*)::text AS c,
                 coalesce(sum(cost),0)::text AS revenue,
                 count(*) FILTER (WHERE status='completed')::text AS ai
          FROM service_records`
    ),
    db.execute(
      sql`SELECT count(*)::text AS c FROM appointments WHERE source='ai' AND status <> 'cancelled'`
    )
  ]);
  const today = /* @__PURE__ */ new Date();
  const iso = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const todayRows = await db.execute(
    sql`SELECT count(*)::text AS c FROM appointments WHERE date = ${iso} AND status <> 'cancelled'`
  );
  return NextResponse.json({
    statuses: statusRows.rows,
    revenue: revenueRows.rows.map((r) => ({ mon: r.mon, total: Number(r.total) })),
    technicians: techRows.rows.map((r) => ({ name: r.name, count: Number(r.c) })),
    totalRecords: Number(countRows.rows[0]?.c ?? 0),
    totalRevenue: Number(countRows.rows[0]?.revenue ?? 0),
    aiBookings: Number(aiRows.rows[0]?.c ?? 0),
    todayJobs: Number(todayRows.rows[0]?.c ?? 0)
  });
}
export {
  GET
};
