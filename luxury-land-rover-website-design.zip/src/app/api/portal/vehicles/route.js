import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { vehicles } from "@/db/schema";
import { getSessionCustomer } from "@/lib/auth";
export const dynamic = "force-dynamic";
async function POST(req) {
  const customer = await getSessionCustomer();
  if (!customer) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const vin = (body.vin || "").trim().toUpperCase();
  const model = (body.model || "").trim();
  const year = Number(body.year);
  const mileage = body.mileage === "" || body.mileage == null ? null : Number(body.mileage);
  if (model.length < 2) return NextResponse.json({ error: "Vehicle model is required." }, { status: 400 });
  if (!Number.isInteger(year) || year < 1948 || year > 2100)
    return NextResponse.json({ error: "A valid year is required." }, { status: 400 });
  if (vin.length < 5) return NextResponse.json({ error: "VIN or chassis number is required." }, { status: 400 });
  if (mileage !== null && (!Number.isFinite(mileage) || mileage < 0))
    return NextResponse.json({ error: "Mileage must be a positive number." }, { status: 400 });
  const [row] = await db.insert(vehicles).values({
    customerId: customer.id,
    vin,
    model,
    year,
    plate: body.plate?.trim() || null,
    color: body.color?.trim() || null,
    mileage: mileage === null ? null : Math.round(mileage)
  }).returning();
  return NextResponse.json({ ok: true, vehicle: row });
}
async function DELETE(req) {
  const customer = await getSessionCustomer();
  if (!customer) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Vehicle id required." }, { status: 400 });
  const [row] = await db.delete(vehicles).where(and(eq(vehicles.id, id), eq(vehicles.customerId, customer.id))).returning();
  if (!row) return NextResponse.json({ error: "Vehicle not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
export {
  DELETE,
  POST
};
