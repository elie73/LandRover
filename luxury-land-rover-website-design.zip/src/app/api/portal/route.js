import { NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { appointments, conversations, serviceRecords, uploads, vehicles } from "@/db/schema";
import { getSessionCustomer } from "@/lib/auth";
export const dynamic = "force-dynamic";
async function GET() {
  const customer = await getSessionCustomer();
  if (!customer) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const [myVehicles, myAppointments, myUploads] = await Promise.all([
    db.select().from(vehicles).where(eq(vehicles.customerId, customer.id)),
    db.select().from(appointments).where(eq(appointments.customerId, customer.id)),
    db.select().from(uploads).where(eq(uploads.customerId, customer.id))
  ]);
  const vehicleIds = myVehicles.map((v) => v.id);
  const records = vehicleIds.length ? await db.select().from(serviceRecords).where(inArray(serviceRecords.vehicleId, vehicleIds)) : [];
  const convIds = myAppointments.map((a) => a.conversationId).filter((v) => v != null);
  const convs = convIds.length ? await db.select().from(conversations).where(inArray(conversations.id, convIds)) : [];
  const convMap = new Map(convs.map((c) => [c.id, c.messages]));
  const vehicleMap = new Map(myVehicles.map((v) => [v.id, v]));
  return NextResponse.json({
    customer: { id: customer.id, name: customer.name, email: customer.email, tier: customer.tier, phone: customer.phone },
    vehicles: myVehicles,
    records: records.sort((a, b) => a.date < b.date ? 1 : -1).map((r) => ({ ...r, vehicle: vehicleMap.get(r.vehicleId)?.model ?? "Vehicle" })),
    appointments: myAppointments.sort((a, b) => a.date < b.date ? 1 : -1).map((a) => ({ ...a, conversation: a.conversationId ? convMap.get(a.conversationId) ?? [] : [] })),
    uploads: myUploads
  });
}
export {
  GET
};
