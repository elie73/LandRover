import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { appointments } from "@/db/schema";
import { getSessionCustomer } from "@/lib/auth";
export const dynamic = "force-dynamic";
async function PATCH(req) {
  const customer = await getSessionCustomer();
  if (!customer) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  if (!body.id) return NextResponse.json({ error: "Booking id required." }, { status: 400 });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(body.date || ""))
    return NextResponse.json({ error: "A valid date (YYYY-MM-DD) is required." }, { status: 400 });
  if (!/^\d{1,2}:\d{2}$/.test(body.time || ""))
    return NextResponse.json({ error: "A valid time (HH:MM) is required." }, { status: 400 });
  const rows = await db.update(appointments).set({
    date: body.date,
    time: body.time,
    notes: body.notes ?? void 0,
    status: "confirmed"
  }).where(and(eq(appointments.id, body.id), eq(appointments.customerId, customer.id))).returning();
  if (!rows.length) return NextResponse.json({ error: "Booking not found." }, { status: 404 });
  return NextResponse.json({ ok: true, appointment: rows[0] });
}
async function DELETE(req) {
  const customer = await getSessionCustomer();
  if (!customer) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Booking id required." }, { status: 400 });
  const rows = await db.delete(appointments).where(and(eq(appointments.id, id), eq(appointments.customerId, customer.id))).returning();
  if (!rows.length) return NextResponse.json({ error: "Booking not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
export {
  DELETE,
  PATCH
};
