import { NextResponse } from "next/server";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { db } from "@/db";
import { uploads } from "@/db/schema";
import { getSessionCustomer } from "@/lib/auth";
export const dynamic = "force-dynamic";
const MAX = 8 * 1024 * 1024;
async function POST(req) {
  const customer = await getSessionCustomer();
  if (!customer) return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  const label = String(form?.get("label") || "Untitled upload").slice(0, 80);
  const kind = String(form?.get("kind") || "photo") === "video" ? "video" : "photo";
  if (!(file instanceof File) || file.size === 0)
    return NextResponse.json({ error: "Attach a file first." }, { status: 400 });
  if (file.size > MAX)
    return NextResponse.json({ error: "Files up to 8 MB only." }, { status: 400 });
  const okType = kind === "video" ? file.type.startsWith("video/") : file.type.startsWith("image/");
  if (!okType)
    return NextResponse.json(
      { error: kind === "video" ? "Videos only (mp4/webm)." : "Images only (jpg/png/webp)." },
      { status: 400 }
    );
  const ext = path.extname(file.name).slice(0, 6) || (kind === "video" ? ".mp4" : ".jpg");
  const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`;
  const dir = path.join(process.cwd(), "public", "uploads");
  await mkdir(dir, { recursive: true });
  const buf = Buffer.from(await file.arrayBuffer());
  await writeFile(path.join(dir, name), buf);
  const [row] = await db.insert(uploads).values({ customerId: customer.id, kind, url: `/uploads/${name}`, label }).returning();
  return NextResponse.json({ ok: true, upload: row });
}
export {
  POST
};
