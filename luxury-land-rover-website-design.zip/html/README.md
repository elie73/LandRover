# Static HTML Export

This folder contains a standalone static HTML version of the Baydoun Land Rover website.

Open `index.html` to browse the static site. Keep the `assets/` folder beside the HTML files when publishing.

The Next.js app remains the full-featured backend version for AI, portal, dashboard, staff, vehicles, and database actions.
