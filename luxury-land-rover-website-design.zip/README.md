# Baydoun Land Rover Website

Premium Land Rover specialist website with a JavaScript/JSX Next.js fullstack app and a standalone static HTML export.

## Project structure

```text
src/app/          Next.js pages and API routes
src/components/   Shared UI, navigation, effects, floating buttons
src/db/           Drizzle database client and PostgreSQL schema
src/lib/          AI engine, auth, service catalogue, utilities
public/images/    Optimized site image assets
html/             Static HTML export for simple publishing/handoff
scripts/          Database seed script
```

## Main app

The full application is the Next.js app in `src/`. It includes:

- AI assistant chat
- customer portal
- Workshop OS admin dashboard
- staff management
- vehicle add/delete
- appointment completion and service history registration
- PostgreSQL/Drizzle backend APIs

## Static HTML export

The `html/` folder contains static `.html` files and `html/assets/`.

Use this only when you need a static handoff. Backend features require the Next.js app.

## Important notes

- Source files are JavaScript/JSX, not TypeScript/TSX.
- `public/uploads/` is ignored because uploaded staff photos are stored in the database as data URLs.
- `.next/` and other build caches are generated and should not be committed.
